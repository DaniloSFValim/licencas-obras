# Sistema de Licenças para Obras em Vias Públicas

Sistema web desenvolvido para a Prefeitura de Niterói para cadastro e gestão de licenças para obras em vias públicas.

## Funcionalidades

- ✅ Autenticação de usuários (admin e operadores)
- ✅ Cadastro de empresas
- ✅ Emissão de licenças com geração automática de PDF
- ✅ Mapa interativo com licenças e denúncias
- ✅ Gestão de denúncias
- ✅ Análise pós-obra
- ✅ Controle de permissões por role

## Requisitos

- Node.js 18+
- PostgreSQL 12+
- PostGIS (extensão do PostgreSQL)

## Instalação Backend

### 1. Clonar repositório

```bash
cd backend
npm install
```

### 2. Configurar variáveis de ambiente

```bash
cp .env.example .env
```

Edite o arquivo `.env` com suas credenciais:

```
DB_HOST=localhost
DB_PORT=5432
DB_NAME=licencas_obras
DB_USER=postgres
DB_PASSWORD=sua_senha

PORT=5000
JWT_SECRET=sua_chave_secreta_longa_aqui
```

### 3. Criar banco de dados

```bash
# No PostgreSQL
createdb licencas_obras

# Habilitar PostGIS
psql -d licencas_obras -c "CREATE EXTENSION postgis;"
```

### 4. Executar schema SQL

```bash
psql -d licencas_obras -f schema.sql
```

### 5. Iniciar servidor

```bash
npm run dev
```

O servidor estará rodando em `http://localhost:5000`

## Credenciais Padrão

- **Email**: admin@niteroi.rj.gov.br
- **Senha**: password123

⚠️ **Altere a senha do admin em produção!**

## Endpoints Principais

### Autenticação

```
POST   /api/auth/login
POST   /api/auth/refresh-token
GET    /api/auth/me
POST   /api/auth/logout
```

### Empresas

```
GET    /api/empresas
GET    /api/empresas/:id
POST   /api/empresas
PUT    /api/empresas/:id
DELETE /api/empresas/:id
```

### Licenças

```
GET    /api/licencas
GET    /api/licencas/:id
GET    /api/licencas/geojson
POST   /api/licencas
PUT    /api/licencas/:id
PATCH  /api/licencas/:id/status
DELETE /api/licencas/:id
```

## Estrutura do Banco de Dados

### Tabelas Principais

- `usuarios` - Usuários do sistema (admin e operadores)
- `empresas` - Dados das empresas autorizadas
- `licencas` - Licenças emitidas para obras
- `denuncias` - Denúncias relacionadas às obras
- `analise_pos_obra` - Análises após conclusão das obras
- `auditoria` - Log de todas as ações no sistema

## Stack Tecnológico

- **Backend**: Node.js + Express
- **Banco de Dados**: PostgreSQL + PostGIS
- **Autenticação**: JWT
- **PDF**: PDFKit
- **Geolocalização**: PostGIS + Leaflet.js (frontend)

## Estrutura de Pastas Backend

```
backend/
├── src/
│   ├── config/          # Configurações (DB, Auth)
│   ├── controllers/     # Lógica de negócio
│   ├── middlewares/     # Middlewares (auth, erros)
│   ├── models/          # Queries e operações BD
│   ├── routes/          # Definição de rotas
│   ├── utils/           # Utilitários (PDF, etc)
│   └── app.js          # Aplicação Express
├── schema.sql          # Schema do BD
├── server.js           # Inicialização
├── package.json
└── .env.example
```

## Próximos Passos

1. Instalar e configurar o frontend (React)
2. Importar o shapefile de Niterói
3. Configurar cron job para expiração de licenças
4. Implementar upload de documentos
5. Integração com denúncias de múltiplos canais

## Suporte

Para dúvidas ou problemas, verifique o console do servidor e os logs do banco de dados.
