-- Enable PostGIS extension
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;

-- ============================================================================
-- TABELA: Usuários (Prefeitura)
-- ============================================================================
CREATE TABLE usuarios (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  senha_hash VARCHAR(255) NOT NULL,
  role VARCHAR(50) DEFAULT 'operador', -- 'admin' ou 'operador'
  ativo BOOLEAN DEFAULT true,
  telefone VARCHAR(20),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ultimo_login TIMESTAMP
);

CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_usuarios_role ON usuarios(role);

-- ============================================================================
-- TABELA: Empresas
-- ============================================================================
CREATE TABLE empresas (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(255) NOT NULL,
  cnpj VARCHAR(14) UNIQUE NOT NULL,
  telefone VARCHAR(20),
  email VARCHAR(255),
  endereco TEXT NOT NULL,
  bairro VARCHAR(100),
  representante VARCHAR(255),
  telefone_representante VARCHAR(20),
  email_representante VARCHAR(255),
  ativo BOOLEAN DEFAULT true,
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  criada_por INT REFERENCES usuarios(id),
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_por INT REFERENCES usuarios(id)
);

CREATE INDEX idx_empresas_cnpj ON empresas(cnpj);
CREATE INDEX idx_empresas_nome ON empresas(nome);
CREATE INDEX idx_empresas_ativo ON empresas(ativo);

-- ============================================================================
-- TABELA: Licenças
-- ============================================================================
CREATE TABLE licencas (
  id SERIAL PRIMARY KEY,
  numero VARCHAR(50) UNIQUE NOT NULL,
  empresa_id INT NOT NULL REFERENCES empresas(id),
  
  -- Dados da Obra
  tipo_obra VARCHAR(100) NOT NULL,
  descricao TEXT,
  local_obra TEXT NOT NULL,
  via_publica VARCHAR(255),
  bairro VARCHAR(100),
  
  -- Responsabilidade
  responsavel_obra VARCHAR(255) NOT NULL,
  telefone_responsavel VARCHAR(20),
  email_responsavel VARCHAR(255),
  
  -- Datas
  data_inicio DATE NOT NULL,
  data_fim DATE NOT NULL,
  data_validade DATE NOT NULL,
  
  -- Restrições
  restricoes TEXT,
  
  -- Localização Geográfica
  localizacao GEOMETRY(Point, 4326) NOT NULL,
  
  -- Financeiro
  taxa_licenca DECIMAL(10,2),
  pago BOOLEAN DEFAULT false,
  data_pagamento DATE,
  
  -- Status
  status VARCHAR(50) DEFAULT 'ativa',
  
  -- PDF & Histórico
  pdf_url VARCHAR(500),
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  criada_por INT NOT NULL REFERENCES usuarios(id),
  emitida_em TIMESTAMP,
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_por INT REFERENCES usuarios(id),
  
  CONSTRAINT check_datas CHECK (data_inicio <= data_fim)
);

CREATE INDEX idx_licencas_numero ON licencas(numero);
CREATE INDEX idx_licencas_empresa ON licencas(empresa_id);
CREATE INDEX idx_licencas_status ON licencas(status);
CREATE INDEX idx_licencas_data_inicio ON licencas(data_inicio);
CREATE INDEX idx_licencas_data_validade ON licencas(data_validade);
CREATE INDEX idx_licencas_localizacao ON licencas USING GIST(localizacao);

-- ============================================================================
-- TABELA: Uploads de Documentos (PDFs de empresas)
-- ============================================================================
CREATE TABLE uploads_empresa (
  id SERIAL PRIMARY KEY,
  licenca_id INT REFERENCES licencas(id),
  tipo_documento VARCHAR(100),
  nome_arquivo VARCHAR(255) NOT NULL,
  caminho_arquivo VARCHAR(500) NOT NULL,
  tamanho_bytes INT,
  hash_arquivo VARCHAR(64),
  upload_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  enviado_por VARCHAR(255)
);

CREATE INDEX idx_uploads_licenca ON uploads_empresa(licenca_id);

-- ============================================================================
-- TABELA: Denúncias
-- ============================================================================
CREATE TABLE denuncias (
  id SERIAL PRIMARY KEY,
  titulo VARCHAR(255),
  descricao TEXT NOT NULL,
  canal VARCHAR(50),
  localizacao GEOMETRY(Point, 4326),
  endereco TEXT,
  
  -- Relacionamento com Licença
  licenca_relacionada_id INT REFERENCES licencas(id),
  
  -- Mídia
  foto_url VARCHAR(500),
  
  -- Status
  status VARCHAR(50) DEFAULT 'aberta',
  observacoes_investigacao TEXT,
  
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  criada_por INT REFERENCES usuarios(id),
  atualizada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizada_por INT REFERENCES usuarios(id)
);

CREATE INDEX idx_denuncias_licenca ON denuncias(licenca_relacionada_id);
CREATE INDEX idx_denuncias_status ON denuncias(status);
CREATE INDEX idx_denuncias_localizacao ON denuncias USING GIST(localizacao);

-- ============================================================================
-- TABELA: Análise Pós-Obra
-- ============================================================================
CREATE TABLE analise_pos_obra (
  id SERIAL PRIMARY KEY,
  licenca_id INT NOT NULL REFERENCES licencas(id),
  data_conclusao DATE NOT NULL,
  
  -- Estado
  estado_local VARCHAR(100),
  descricao_estado TEXT,
  
  -- Evidências
  foto_antes_url VARCHAR(500),
  foto_depois_url VARCHAR(500),
  
  -- Observações
  observacoes TEXT,
  responsavel_analise VARCHAR(255),
  
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  criada_por INT REFERENCES usuarios(id)
);

CREATE INDEX idx_analise_licenca ON analise_pos_obra(licenca_id);

-- ============================================================================
-- TABELA: Auditoria
-- ============================================================================
CREATE TABLE auditoria (
  id SERIAL PRIMARY KEY,
  usuario_id INT REFERENCES usuarios(id),
  entidade VARCHAR(100),
  entidade_id INT,
  acao VARCHAR(50),
  dados_alterados JSONB,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ip_address INET
);

CREATE INDEX idx_auditoria_usuario ON auditoria(usuario_id);
CREATE INDEX idx_auditoria_entidade ON auditoria(entidade);
CREATE INDEX idx_auditoria_timestamp ON auditoria(timestamp);

-- ============================================================================
-- TABELA: Limites Municipais (Shapefile de Niterói)
-- ============================================================================
CREATE TABLE limite_municipal (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(255),
  geometria GEOMETRY(Polygon, 4326),
  area_m2 DECIMAL(15,2),
  criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_limite_geometria ON limite_municipal USING GIST(geometria);

-- ============================================================================
-- VIEW: Licenças com Dados da Empresa
-- ============================================================================
CREATE VIEW licencas_completas AS
SELECT 
  l.id,
  l.numero,
  l.status,
  l.data_inicio,
  l.data_fim,
  l.data_validade,
  l.localizacao,
  l.local_obra,
  l.via_publica,
  l.tipo_obra,
  e.nome as empresa_nome,
  e.cnpj as empresa_cnpj,
  e.email as empresa_email,
  u.nome as criada_por_nome,
  l.criada_em,
  l.emitida_em,
  l.pdf_url
FROM licencas l
JOIN empresas e ON l.empresa_id = e.id
JOIN usuarios u ON l.criada_por = u.id;

-- ============================================================================
-- FUNÇÃO: Atualizar timestamp
-- ============================================================================
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.atualizada_em = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TRIGGERS: Atualizar timestamps automaticamente
-- ============================================================================
CREATE TRIGGER trigger_usuarios_timestamp BEFORE UPDATE ON usuarios
  FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_empresas_timestamp BEFORE UPDATE ON empresas
  FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_licencas_timestamp BEFORE UPDATE ON licencas
  FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trigger_denuncias_timestamp BEFORE UPDATE ON denuncias
  FOR EACH ROW EXECUTE FUNCTION update_timestamp();

-- ============================================================================
-- SEED: Usuário Admin Padrão
-- ============================================================================
INSERT INTO usuarios (nome, email, senha_hash, role, ativo)
VALUES (
  'Administrador',
  'admin@niteroi.rj.gov.br',
  '$2a$10$N9qo8uLOickgx2ZMRZoMyu1RMdzAWjZHrAT7kHnYOMiMnHK3gA2Aa', -- senha: password123
  'admin',
  true
)
ON CONFLICT (email) DO NOTHING;
