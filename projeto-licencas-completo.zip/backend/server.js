import dotenv from 'dotenv';
import app from './src/app.js';
import pool from './src/config/database.js';
import { iniciarCronJobs } from './scripts/cronJobs.js';

dotenv.config();

const PORT = process.env.PORT || 5000;

// Testa conexão com banco de dados
async function testarBancoDados() {
  try {
    const resultado = await pool.query('SELECT NOW()');
    console.log('✅ Conectado ao banco de dados:', resultado.rows[0]);
    return true;
  } catch (error) {
    console.error('❌ Erro ao conectar ao banco de dados:', error.message);
    return false;
  }
}

// Inicia servidor
async function iniciarServidor() {
  try {
    // Testa conexão com BD
    const bdConectado = await testarBancoDados();
    
    if (!bdConectado) {
      console.error('❌ Não foi possível conectar ao banco de dados. Verifique as variáveis de ambiente.');
      process.exit(1);
    }

    // Inicia servidor HTTP
    app.listen(PORT, () => {
      console.log(`\n${'='.repeat(50)}`);
      console.log(`✅ Servidor iniciado na porta ${PORT}`);
      console.log(`📍 http://localhost:${PORT}`);
      console.log(`${'='.repeat(50)}\n`);

      // Inicia cron jobs
      iniciarCronJobs();
    });
  } catch (error) {
    console.error('❌ Erro ao iniciar servidor:', error);
    process.exit(1);
  }
}

// Trata sinais de encerramento
process.on('SIGINT', () => {
  console.log('\n\n🛑 Encerrando servidor...');
  pool.end(() => {
    console.log('✅ Conexões do banco encerradas');
    process.exit(0);
  });
});

iniciarServidor();
