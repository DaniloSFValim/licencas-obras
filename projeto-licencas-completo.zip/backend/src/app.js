import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { logRequest, errorHandler } from './middlewares/index.js';

// Importa rotas
import authRoutes from './routes/auth.js';
import empresasRoutes from './routes/empresas.js';
import licencasRoutes from './routes/licencas.js';
import denunciasRoutes from './routes/denuncias.js';
import analiseRoutes from './routes/analise.js';

dotenv.config();

const app = express();

// ============================================================================
// MIDDLEWARES GLOBAIS
// ============================================================================

// CORS
app.use(cors({
  origin: [
    'http://localhost:3000',
    'http://localhost:5173',
    process.env.FRONTEND_URL || '*'
  ],
  credentials: true
}));

// Parse JSON
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Log de requisições
app.use(logRequest);

// Servir arquivos estáticos (uploads)
app.use('/uploads', express.static('uploads'));

// ============================================================================
// ROTAS
// ============================================================================

app.use('/api/auth', authRoutes);
app.use('/api/empresas', empresasRoutes);
app.use('/api/licencas', licencasRoutes);
app.use('/api/denuncias', denunciasRoutes);
app.use('/api/analise', analiseRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({
    sucesso: true,
    mensagem: 'Sistema funcionando corretamente',
    timestamp: new Date().toISOString()
  });
});

// 404
app.use((req, res) => {
  res.status(404).json({
    sucesso: false,
    mensagem: 'Rota não encontrada'
  });
});

// ============================================================================
// TRATAMENTO DE ERROS
// ============================================================================

app.use(errorHandler);

export default app;
