import {
  listarAnalisesPorLicenca,
  findAnaliseById,
  criarAnalise,
  atualizarAnalise,
  deletarAnalise
} from '../models/denuncias.js';
import { findLicencaById, atualizarStatusLicenca } from '../models/licencas.js';

/**
 * Listar análises por licença
 */
export const getAnalisesPorLicenca = async (req, res) => {
  try {
    const { licenca_id } = req.params;

    const licenca = await findLicencaById(licenca_id);
    if (!licenca) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Licença não encontrada'
      });
    }

    const analises = await listarAnalisesPorLicenca(licenca_id);

    res.json({
      sucesso: true,
      dados: {
        total: analises.length,
        analises
      }
    });
  } catch (error) {
    console.error('Erro ao listar análises:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao listar análises'
    });
  }
};

/**
 * Obter análise por ID
 */
export const getAnaliseById = async (req, res) => {
  try {
    const { id } = req.params;

    const analise = await findAnaliseById(id);

    if (!analise) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Análise não encontrada'
      });
    }

    res.json({
      sucesso: true,
      dados: analise
    });
  } catch (error) {
    console.error('Erro ao obter análise:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao obter análise'
    });
  }
};

/**
 * Criar análise pós-obra
 */
export const postAnalise = async (req, res) => {
  try {
    const {
      licenca_id,
      data_conclusao,
      estado_local,
      descricao_estado,
      foto_antes_url,
      foto_depois_url,
      observacoes,
      responsavel_analise
    } = req.body;

    // Validações
    if (!licenca_id || !data_conclusao) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'Licença e data de conclusão são obrigatórias'
      });
    }

    // Verifica se licença existe
    const licenca = await findLicencaById(licenca_id);
    if (!licenca) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Licença não encontrada'
      });
    }

    // Cria análise
    const novaAnalise = await criarAnalise(
      {
        licenca_id,
        data_conclusao,
        estado_local,
        descricao_estado,
        foto_antes_url,
        foto_depois_url,
        observacoes,
        responsavel_analise
      },
      req.usuario.id
    );

    // Atualiza status da licença para "concluida"
    await atualizarStatusLicenca(licenca_id, 'concluida');

    res.status(201).json({
      sucesso: true,
      mensagem: 'Análise criada e licença marcada como concluída',
      dados: novaAnalise
    });
  } catch (error) {
    console.error('Erro ao criar análise:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao criar análise'
    });
  }
};

/**
 * Atualizar análise
 */
export const putAnalise = async (req, res) => {
  try {
    const { id } = req.params;
    const dados = req.body;

    const analise = await findAnaliseById(id);

    if (!analise) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Análise não encontrada'
      });
    }

    const analiseAtualizada = await atualizarAnalise(id, dados, req.usuario.id);

    res.json({
      sucesso: true,
      mensagem: 'Análise atualizada com sucesso',
      dados: analiseAtualizada
    });
  } catch (error) {
    console.error('Erro ao atualizar análise:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao atualizar análise'
    });
  }
};

/**
 * Deletar análise
 */
export const deleteAnalise = async (req, res) => {
  try {
    const { id } = req.params;

    const analise = await findAnaliseById(id);

    if (!analise) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Análise não encontrada'
      });
    }

    await deletarAnalise(id);

    res.json({
      sucesso: true,
      mensagem: 'Análise deletada com sucesso'
    });
  } catch (error) {
    console.error('Erro ao deletar análise:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao deletar análise'
    });
  }
};
