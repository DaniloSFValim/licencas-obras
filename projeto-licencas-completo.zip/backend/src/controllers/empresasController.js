import {
  listarEmpresas,
  findEmpresaById,
  findEmpresaByCNPJ,
  criarEmpresa,
  atualizarEmpresa,
  deletarEmpresa
} from '../models/usuarios.js';

/**
 * Listar empresas
 */
export const getEmpresas = async (req, res) => {
  try {
    const { nome, cnpj } = req.query;
    const filtros = {};

    if (nome) filtros.nome = nome;
    if (cnpj) filtros.cnpj = cnpj;

    const empresas = await listarEmpresas(filtros);

    res.json({
      sucesso: true,
      dados: {
        total: empresas.length,
        empresas
      }
    });
  } catch (error) {
    console.error('Erro ao listar empresas:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao listar empresas'
    });
  }
};

/**
 * Obter empresa por ID
 */
export const getEmpresaById = async (req, res) => {
  try {
    const { id } = req.params;

    const empresa = await findEmpresaById(id);

    if (!empresa) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Empresa não encontrada'
      });
    }

    res.json({
      sucesso: true,
      dados: empresa
    });
  } catch (error) {
    console.error('Erro ao obter empresa:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao obter empresa'
    });
  }
};

/**
 * Criar empresa
 */
export const postEmpresa = async (req, res) => {
  try {
    const {
      nome,
      cnpj,
      telefone,
      email,
      endereco,
      bairro,
      representante,
      telefone_representante,
      email_representante
    } = req.body;

    // Validações básicas
    if (!nome || !cnpj || !endereco) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'Nome, CNPJ e endereço são obrigatórios'
      });
    }

    // Verifica se CNPJ já existe
    const empresaExistente = await findEmpresaByCNPJ(cnpj);
    if (empresaExistente) {
      return res.status(409).json({
        sucesso: false,
        mensagem: 'CNPJ já cadastrado'
      });
    }

    const novaEmpresa = await criarEmpresa(
      {
        nome,
        cnpj,
        telefone,
        email,
        endereco,
        bairro,
        representante,
        telefone_representante,
        email_representante
      },
      req.usuario.id
    );

    res.status(201).json({
      sucesso: true,
      mensagem: 'Empresa criada com sucesso',
      dados: novaEmpresa
    });
  } catch (error) {
    console.error('Erro ao criar empresa:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao criar empresa'
    });
  }
};

/**
 * Atualizar empresa
 */
export const putEmpresa = async (req, res) => {
  try {
    const { id } = req.params;
    const dados = req.body;

    const empresa = await findEmpresaById(id);

    if (!empresa) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Empresa não encontrada'
      });
    }

    const empresaAtualizada = await atualizarEmpresa(id, dados, req.usuario.id);

    res.json({
      sucesso: true,
      mensagem: 'Empresa atualizada com sucesso',
      dados: empresaAtualizada
    });
  } catch (error) {
    console.error('Erro ao atualizar empresa:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao atualizar empresa'
    });
  }
};

/**
 * Deletar empresa (soft delete)
 */
export const deleteEmpresa = async (req, res) => {
  try {
    const { id } = req.params;

    const empresa = await findEmpresaById(id);

    if (!empresa) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Empresa não encontrada'
      });
    }

    await deletarEmpresa(id);

    res.json({
      sucesso: true,
      mensagem: 'Empresa deletada com sucesso'
    });
  } catch (error) {
    console.error('Erro ao deletar empresa:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao deletar empresa'
    });
  }
};
