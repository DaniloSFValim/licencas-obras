import { findUsuarioByEmail, criarUsuario, atualizarUltimoLogin } from '../models/usuarios.js';
import { generateToken, hashPassword, comparePassword } from '../config/auth.js';

/**
 * Login
 */
export const login = async (req, res) => {
  try {
    const { email, senha } = req.body;

    if (!email || !senha) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'Email e senha são obrigatórios'
      });
    }

    const usuario = await findUsuarioByEmail(email);

    if (!usuario) {
      return res.status(401).json({
        sucesso: false,
        mensagem: 'Email ou senha incorretos'
      });
    }

    if (!usuario.ativo) {
      return res.status(403).json({
        sucesso: false,
        mensagem: 'Usuário desativado'
      });
    }

    const senhaValida = await comparePassword(senha, usuario.senha_hash);

    if (!senhaValida) {
      return res.status(401).json({
        sucesso: false,
        mensagem: 'Email ou senha incorretos'
      });
    }

    // Atualiza último login
    await atualizarUltimoLogin(usuario.id);

    // Gera token JWT
    const token = generateToken({
      id: usuario.id,
      email: usuario.email,
      role: usuario.role
    });

    res.json({
      sucesso: true,
      mensagem: 'Login realizado com sucesso',
      dados: {
        token,
        usuario: {
          id: usuario.id,
          nome: usuario.nome,
          email: usuario.email,
          role: usuario.role
        }
      }
    });
  } catch (error) {
    console.error('Erro ao fazer login:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao fazer login'
    });
  }
};

/**
 * Refresh Token
 */
export const refreshToken = async (req, res) => {
  try {
    const { id, email, role } = req.usuario;

    const novoToken = generateToken({
      id,
      email,
      role
    });

    res.json({
      sucesso: true,
      dados: { token: novoToken }
    });
  } catch (error) {
    console.error('Erro ao renovar token:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao renovar token'
    });
  }
};

/**
 * Obter dados do usuário autenticado
 */
export const meUsuario = async (req, res) => {
  try {
    const { id, email, role } = req.usuario;

    res.json({
      sucesso: true,
      dados: {
        id,
        email,
        role
      }
    });
  } catch (error) {
    console.error('Erro ao obter usuário:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao obter dados do usuário'
    });
  }
};

/**
 * Logout (client-side apenas, mas deixar endpoint aqui)
 */
export const logout = async (req, res) => {
  res.json({
    sucesso: true,
    mensagem: 'Logout realizado. Remova o token do cliente.'
  });
};
