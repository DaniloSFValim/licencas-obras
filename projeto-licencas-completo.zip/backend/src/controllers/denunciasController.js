import {
  listarDenuncias,
  findDenunciaById,
  criarDenuncia,
  atualizarDenuncia,
  relacionarDenunciaComLicenca,
  obterDenunciasGeoJSON,
  deletarDenuncia
} from '../models/denuncias.js';
import { findLicencaById } from '../models/licencas.js';

/**
 * Listar denúncias
 */
export const getDenuncias = async (req, res) => {
  try {
    const { status, canal, licenca_id } = req.query;
    
    const filtros = {};
    if (status) filtros.status = status;
    if (canal) filtros.canal = canal;
    if (licenca_id) filtros.licenca_id = licenca_id;

    const denuncias = await listarDenuncias(filtros);

    res.json({
      sucesso: true,
      dados: {
        total: denuncias.length,
        denuncias
      }
    });
  } catch (error) {
    console.error('Erro ao listar denúncias:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao listar denúncias'
    });
  }
};

/**
 * Obter denúncia por ID
 */
export const getDenunciaById = async (req, res) => {
  try {
    const { id } = req.params;

    const denuncia = await findDenunciaById(id);

    if (!denuncia) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Denúncia não encontrada'
      });
    }

    res.json({
      sucesso: true,
      dados: denuncia
    });
  } catch (error) {
    console.error('Erro ao obter denúncia:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao obter denúncia'
    });
  }
};

/**
 * Criar denúncia
 */
export const postDenuncia = async (req, res) => {
  try {
    const {
      titulo,
      descricao,
      canal,
      endereco,
      latitude,
      longitude,
      foto_url,
      licenca_relacionada_id
    } = req.body;

    // Validações
    if (!descricao) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'Descrição é obrigatória'
      });
    }

    // Verifica se licença existe (se fornecida)
    if (licenca_relacionada_id) {
      const licenca = await findLicencaById(licenca_relacionada_id);
      if (!licenca) {
        return res.status(404).json({
          sucesso: false,
          mensagem: 'Licença relacionada não encontrada'
        });
      }
    }

    const novaDenuncia = await criarDenuncia(
      {
        titulo,
        descricao,
        canal: canal || 'manual',
        endereco,
        latitude,
        longitude,
        foto_url,
        licenca_relacionada_id
      },
      req.usuario.id
    );

    res.status(201).json({
      sucesso: true,
      mensagem: 'Denúncia criada com sucesso',
      dados: novaDenuncia
    });
  } catch (error) {
    console.error('Erro ao criar denúncia:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao criar denúncia'
    });
  }
};

/**
 * Atualizar denúncia
 */
export const putDenuncia = async (req, res) => {
  try {
    const { id } = req.params;
    const dados = req.body;

    const denuncia = await findDenunciaById(id);

    if (!denuncia) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Denúncia não encontrada'
      });
    }

    const denunciaAtualizada = await atualizarDenuncia(id, dados, req.usuario.id);

    res.json({
      sucesso: true,
      mensagem: 'Denúncia atualizada com sucesso',
      dados: denunciaAtualizada
    });
  } catch (error) {
    console.error('Erro ao atualizar denúncia:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao atualizar denúncia'
    });
  }
};

/**
 * Relacionar denúncia com licença
 */
export const patchDenunciaRelacionarLicenca = async (req, res) => {
  try {
    const { id } = req.params;
    const { licenca_id } = req.body;

    const denuncia = await findDenunciaById(id);

    if (!denuncia) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Denúncia não encontrada'
      });
    }

    if (licenca_id) {
      const licenca = await findLicencaById(licenca_id);
      if (!licenca) {
        return res.status(404).json({
          sucesso: false,
          mensagem: 'Licença não encontrada'
        });
      }
    }

    const denunciaAtualizada = await relacionarDenunciaComLicenca(id, licenca_id || null);

    res.json({
      sucesso: true,
      mensagem: 'Denúncia relacionada com sucesso',
      dados: denunciaAtualizada
    });
  } catch (error) {
    console.error('Erro ao relacionar denúncia:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao relacionar denúncia'
    });
  }
};

/**
 * Obter denúncias em formato GeoJSON (para mapa)
 */
export const getDenunciasGeoJSON = async (req, res) => {
  try {
    const { status, licenca_id } = req.query;

    const filtros = {};
    if (status) filtros.status = status;
    if (licenca_id) filtros.licenca_id = licenca_id;

    const geojson = await obterDenunciasGeoJSON(filtros);

    res.json({
      sucesso: true,
      dados: geojson
    });
  } catch (error) {
    console.error('Erro ao obter GeoJSON de denúncias:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao obter dados geográficos'
    });
  }
};

/**
 * Deletar denúncia
 */
export const deleteDenuncia = async (req, res) => {
  try {
    const { id } = req.params;

    const denuncia = await findDenunciaById(id);

    if (!denuncia) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Denúncia não encontrada'
      });
    }

    await deletarDenuncia(id);

    res.json({
      sucesso: true,
      mensagem: 'Denúncia deletada com sucesso'
    });
  } catch (error) {
    console.error('Erro ao deletar denúncia:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao deletar denúncia'
    });
  }
};
