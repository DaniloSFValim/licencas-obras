import {
  listarLicencas,
  findLicencaById,
  findLicencaByNumero,
  gerarNumeroLicenca,
  criarLicenca,
  atualizarLicenca,
  atualizarStatusLicenca,
  obterLicencasGeoJSON,
  deletarLicenca
} from '../models/licencas.js';
import { findEmpresaById } from '../models/usuarios.js';
import { gerarPDFLicenca } from '../utils/pdfGenerator.js';

/**
 * Listar licenças
 */
export const getLicencas = async (req, res) => {
  try {
    const { status, empresa_id, numero, data_inicio, data_fim } = req.query;
    
    const filtros = {};
    if (status) filtros.status = status;
    if (empresa_id) filtros.empresa_id = empresa_id;
    if (numero) filtros.numero = numero;
    if (data_inicio && data_fim) {
      filtros.data_inicio = data_inicio;
      filtros.data_fim = data_fim;
    }

    const licencas = await listarLicencas(filtros);

    res.json({
      sucesso: true,
      dados: {
        total: licencas.length,
        licencas
      }
    });
  } catch (error) {
    console.error('Erro ao listar licenças:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao listar licenças'
    });
  }
};

/**
 * Obter licença por ID
 */
export const getLicencaById = async (req, res) => {
  try {
    const { id } = req.params;

    const licenca = await findLicencaById(id);

    if (!licenca) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Licença não encontrada'
      });
    }

    res.json({
      sucesso: true,
      dados: licenca
    });
  } catch (error) {
    console.error('Erro ao obter licença:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao obter licença'
    });
  }
};

/**
 * Criar licença
 */
export const postLicenca = async (req, res) => {
  try {
    const {
      empresa_id,
      tipo_obra,
      descricao,
      local_obra,
      via_publica,
      bairro,
      responsavel_obra,
      telefone_responsavel,
      email_responsavel,
      data_inicio,
      data_fim,
      data_validade,
      restricoes,
      latitude,
      longitude,
      taxa_licenca
    } = req.body;

    // Validações
    if (!empresa_id || !tipo_obra || !local_obra || !responsavel_obra) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'Empresa, tipo de obra, local e responsável são obrigatórios'
      });
    }

    // Verifica se empresa existe
    const empresa = await findEmpresaById(empresa_id);
    if (!empresa) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Empresa não encontrada'
      });
    }

    // Gera número único
    const numero = await gerarNumeroLicenca();

    // Gera PDF
    let pdfPath = null;
    try {
      pdfPath = await gerarPDFLicenca({
        numero,
        empresa_nome: empresa.nome,
        empresa_cnpj: empresa.cnpj,
        tipo_obra,
        local_obra,
        via_publica,
        responsavel_obra,
        data_inicio,
        data_fim,
        data_validade,
        restricoes,
        taxa_licenca
      });
    } catch (error) {
      console.warn('Aviso: Não foi possível gerar PDF, continuando...', error);
    }

    // Cria licença
    const novaLicenca = await criarLicenca(
      {
        empresa_id,
        numero,
        tipo_obra,
        descricao,
        local_obra,
        via_publica,
        bairro,
        responsavel_obra,
        telefone_responsavel,
        email_responsavel,
        data_inicio,
        data_fim,
        data_validade,
        restricoes,
        latitude,
        longitude,
        taxa_licenca,
        pdf_url: pdfPath
      },
      req.usuario.id
    );

    res.status(201).json({
      sucesso: true,
      mensagem: 'Licença criada com sucesso',
      dados: {
        ...novaLicenca,
        pdf_url: pdfPath
      }
    });
  } catch (error) {
    console.error('Erro ao criar licença:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao criar licença'
    });
  }
};

/**
 * Atualizar licença
 */
export const putLicenca = async (req, res) => {
  try {
    const { id } = req.params;
    const dados = req.body;

    const licenca = await findLicencaById(id);

    if (!licenca) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Licença não encontrada'
      });
    }

    const licencaAtualizada = await atualizarLicenca(id, dados, req.usuario.id);

    res.json({
      sucesso: true,
      mensagem: 'Licença atualizada com sucesso',
      dados: licencaAtualizada
    });
  } catch (error) {
    console.error('Erro ao atualizar licença:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao atualizar licença'
    });
  }
};

/**
 * Atualizar status da licença
 */
export const patchLicencaStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const statusValidos = ['ativa', 'expirada', 'concluida', 'cancelada'];

    if (!statusValidos.includes(status)) {
      return res.status(400).json({
        sucesso: false,
        mensagem: `Status inválido. Valores aceitos: ${statusValidos.join(', ')}`
      });
    }

    const licenca = await findLicencaById(id);

    if (!licenca) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Licença não encontrada'
      });
    }

    const licencaAtualizada = await atualizarStatusLicenca(id, status);

    res.json({
      sucesso: true,
      mensagem: 'Status da licença atualizado',
      dados: licencaAtualizada
    });
  } catch (error) {
    console.error('Erro ao atualizar status:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao atualizar status da licença'
    });
  }
};

/**
 * Obter licenças em formato GeoJSON (para mapa)
 */
export const getLicencasGeoJSON = async (req, res) => {
  try {
    const { status, empresa_id } = req.query;

    const filtros = {};
    if (status) filtros.status = status;
    if (empresa_id) filtros.empresa_id = empresa_id;

    const geojson = await obterLicencasGeoJSON(filtros);

    res.json({
      sucesso: true,
      dados: geojson
    });
  } catch (error) {
    console.error('Erro ao obter GeoJSON:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao obter dados geográficos'
    });
  }
};

/**
 * Deletar licença (soft delete)
 */
export const deleteLicenca = async (req, res) => {
  try {
    const { id } = req.params;

    const licenca = await findLicencaById(id);

    if (!licenca) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Licença não encontrada'
      });
    }

    await deletarLicenca(id);

    res.json({
      sucesso: true,
      mensagem: 'Licença deletada com sucesso'
    });
  } catch (error) {
    console.error('Erro ao deletar licença:', error);
    res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao deletar licença'
    });
  }
};
