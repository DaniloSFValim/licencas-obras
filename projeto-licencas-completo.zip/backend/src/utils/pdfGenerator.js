import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadsDir = path.join(__dirname, '../../uploads');

// Cria diretório se não existir
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

/**
 * Gera PDF de licença
 */
export const gerarPDFLicenca = async (dados) => {
  return new Promise((resolve, reject) => {
    try {
      const {
        numero,
        empresa_nome,
        empresa_cnpj,
        tipo_obra,
        local_obra,
        via_publica,
        responsavel_obra,
        data_inicio,
        data_fim,
        data_validade,
        restricoes,
        taxa_licenca
      } = dados;

      // Nome do arquivo
      const nomeArquivo = `licenca_${numero.replace(/-/g, '_')}.pdf`;
      const caminhoCompleto = path.join(uploadsDir, nomeArquivo);

      // Cria documento
      const doc = new PDFDocument({
        size: 'A4',
        margin: 50
      });

      // Pipe para arquivo
      const stream = fs.createWriteStream(caminhoCompleto);
      doc.pipe(stream);

      // Cabeçalho
      doc.fontSize(20).font('Helvetica-Bold').text('LICENÇA PARA OBRA', { align: 'center' });
      doc.fontSize(12).font('Helvetica').text('Em Via Pública', { align: 'center' });
      doc.moveDown();

      // Informações da Prefeitura
      doc.fontSize(10).font('Helvetica-Bold').text('Prefeitura de Niterói - RJ');
      doc.fontSize(9).font('Helvetica').text('Secretaria de Obras e Infraestrutura');
      doc.moveDown();

      // Número e data
      doc.fontSize(11).font('Helvetica-Bold').text(`Número: ${numero}`);
      doc.fontSize(9).font('Helvetica').text(`Emitida em: ${new Date().toLocaleDateString('pt-BR')}`);
      doc.moveDown();

      // Linha divisória
      doc.moveTo(50, doc.y).lineTo(545, doc.y).stroke();
      doc.moveDown();

      // Seção: Empresa
      doc.fontSize(11).font('Helvetica-Bold').text('DADOS DA EMPRESA');
      doc.fontSize(9).font('Helvetica')
        .text(`Nome: ${empresa_nome}`)
        .text(`CNPJ: ${empresa_cnpj}`);
      doc.moveDown();

      // Seção: Obra
      doc.fontSize(11).font('Helvetica-Bold').text('INFORMAÇÕES DA OBRA');
      doc.fontSize(9).font('Helvetica')
        .text(`Tipo de Obra: ${tipo_obra}`)
        .text(`Local: ${local_obra}`)
        .text(`Via Pública: ${via_publica}`);
      doc.moveDown();

      // Seção: Responsável
      doc.fontSize(11).font('Helvetica-Bold').text('RESPONSÁVEL PELA OBRA');
      doc.fontSize(9).font('Helvetica').text(`Nome: ${responsavel_obra}`);
      doc.moveDown();

      // Seção: Prazos
      doc.fontSize(11).font('Helvetica-Bold').text('PRAZOS');
      doc.fontSize(9).font('Helvetica')
        .text(`Início: ${new Date(data_inicio).toLocaleDateString('pt-BR')}`)
        .text(`Término: ${new Date(data_fim).toLocaleDateString('pt-BR')}`)
        .text(`Validade: ${new Date(data_validade).toLocaleDateString('pt-BR')}`);
      doc.moveDown();

      // Seção: Restrições
      if (restricoes) {
        doc.fontSize(11).font('Helvetica-Bold').text('RESTRIÇÕES');
        doc.fontSize(9).font('Helvetica').text(restricoes, {
          width: 445,
          align: 'left'
        });
        doc.moveDown();
      }

      // Seção: Taxa
      if (taxa_licenca) {
        doc.fontSize(11).font('Helvetica-Bold').text('TAXA DE LICENÇA');
        doc.fontSize(9).font('Helvetica').text(`R$ ${taxa_licenca.toFixed(2)}`);
        doc.moveDown();
      }

      // Linha divisória
      doc.moveTo(50, doc.y).lineTo(545, doc.y).stroke();
      doc.moveDown();

      // Rodapé
      doc.fontSize(8).font('Helvetica').text(
        'Este documento é válido apenas quando acompanhado da assinatura eletrônica do órgão emissor.',
        { align: 'center' }
      );

      // Finaliza documento
      doc.end();

      // Quando o arquivo terminar de ser escrito
      stream.on('finish', () => {
        resolve(`/uploads/${nomeArquivo}`);
      });

      stream.on('error', (err) => {
        reject(err);
      });
    } catch (error) {
      reject(error);
    }
  });
};
