import { verifyToken, extractTokenFromHeader } from '../config/auth.js';

/**
 * Middleware: Verifica se usuário está autenticado
 */
export const authenticate = (req, res, next) => {
  const token = extractTokenFromHeader(req);
  
  if (!token) {
    return res.status(401).json({
      sucesso: false,
      mensagem: 'Token não fornecido. Autentique-se.'
    });
  }

  try {
    const decoded = verifyToken(token);
    req.usuario = decoded;
    next();
  } catch (error) {
    return res.status(401).json({
      sucesso: false,
      mensagem: 'Token inválido ou expirado'
    });
  }
};

/**
 * Middleware: Verifica role do usuário
 */
export const authorize = (...rolesPermitidos) => {
  return (req, res, next) => {
    if (!req.usuario) {
      return res.status(401).json({
        sucesso: false,
        mensagem: 'Usuário não autenticado'
      });
    }

    if (!rolesPermitidos.includes(req.usuario.role)) {
      return res.status(403).json({
        sucesso: false,
        mensagem: 'Você não tem permissão para acessar este recurso'
      });
    }

    next();
  };
};

/**
 * Middleware: Tratamento de erros
 */
export const errorHandler = (err, req, res, next) => {
  console.error('Erro:', err);

  // Erro de banco de dados
  if (err.code === '23505') {
    return res.status(409).json({
      sucesso: false,
      mensagem: 'Recurso já existe (violação de chave única)'
    });
  }

  if (err.code === '23503') {
    return res.status(400).json({
      sucesso: false,
      mensagem: 'Referência inválida (foreign key)'
    });
  }

  // Erro genérico
  res.status(err.status || 500).json({
    sucesso: false,
    mensagem: err.message || 'Erro interno do servidor'
  });
};

/**
 * Middleware: Log de requisições
 */
export const logRequest = (req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path}`);
  next();
};
