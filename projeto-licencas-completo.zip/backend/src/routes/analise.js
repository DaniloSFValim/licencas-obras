import express from 'express';
import {
  getAnalisesPorLicenca,
  getAnaliseById,
  postAnalise,
  putAnalise,
  deleteAnalise
} from '../controllers/analiseController.js';
import { authenticate } from '../middlewares/index.js';

const router = express.Router();

// Todas as rotas requerem autenticação
router.use(authenticate);

router.get('/licenca/:licenca_id', getAnalisesPorLicenca);
router.get('/:id', getAnaliseById);
router.post('/', postAnalise);
router.put('/:id', putAnalise);
router.delete('/:id', deleteAnalise);

export default router;
