import express from 'express';
import {
  getDenuncias,
  getDenunciaById,
  postDenuncia,
  putDenuncia,
  patchDenunciaRelacionarLicenca,
  getDenunciasGeoJSON,
  deleteDenuncia
} from '../controllers/denunciasController.js';
import { authenticate } from '../middlewares/index.js';

const router = express.Router();

// Todas as rotas requerem autenticação
router.use(authenticate);

router.get('/', getDenuncias);
router.get('/geojson', getDenunciasGeoJSON);
router.get('/:id', getDenunciaById);
router.post('/', postDenuncia);
router.put('/:id', putDenuncia);
router.patch('/:id/relacionar-licenca', patchDenunciaRelacionarLicenca);
router.delete('/:id', deleteDenuncia);

export default router;
