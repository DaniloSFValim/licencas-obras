import express from 'express';
import { login, refreshToken, meUsuario, logout } from '../controllers/authController.js';
import { authenticate } from '../middlewares/index.js';

const router = express.Router();

router.post('/login', login);
router.post('/refresh-token', authenticate, refreshToken);
router.get('/me', authenticate, meUsuario);
router.post('/logout', authenticate, logout);

export default router;
