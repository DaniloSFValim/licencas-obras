import express from 'express';
import {
  getEmpresas,
  getEmpresaById,
  postEmpresa,
  putEmpresa,
  deleteEmpresa
} from '../controllers/empresasController.js';
import { authenticate } from '../middlewares/index.js';

const router = express.Router();

// Todas as rotas requerem autenticação
router.use(authenticate);

router.get('/', getEmpresas);
router.get('/:id', getEmpresaById);
router.post('/', postEmpresa);
router.put('/:id', putEmpresa);
router.delete('/:id', deleteEmpresa);

export default router;
