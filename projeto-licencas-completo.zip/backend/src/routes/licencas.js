import express from 'express';
import {
  getLicencas,
  getLicencaById,
  postLicenca,
  putLicenca,
  patchLicencaStatus,
  getLicencasGeoJSON,
  deleteLicenca
} from '../controllers/licencasController.js';
import { authenticate } from '../middlewares/index.js';

const router = express.Router();

// Todas as rotas requerem autenticação
router.use(authenticate);

router.get('/', getLicencas);
router.get('/geojson', getLicencasGeoJSON);
router.get('/:id', getLicencaById);
router.post('/', postLicenca);
router.put('/:id', putLicenca);
router.patch('/:id/status', patchLicencaStatus);
router.delete('/:id', deleteLicenca);

export default router;
