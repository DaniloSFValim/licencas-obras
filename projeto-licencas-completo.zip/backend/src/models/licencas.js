import pool from '../config/database.js';

// ============================================================================
// LICENÇAS
// ============================================================================

/**
 * Gera número único para licença
 */
export const gerarNumeroLicenca = async () => {
  const resultado = await pool.query(
    `SELECT COALESCE(COUNT(*), 0) + 1 as numero FROM licencas 
     WHERE DATE(criada_em) = CURRENT_DATE`
  );
  
  const numero = resultado.rows[0].numero;
  const ano = new Date().getFullYear();
  return `LIC-${ano}-${String(numero).padStart(5, '0')}`;
};

/**
 * Lista licenças com filtros
 */
export const listarLicencas = async (filtros = {}) => {
  let query = `
    SELECT 
      l.id, l.numero, l.status, l.data_inicio, l.data_fim, l.data_validade,
      l.local_obra, l.via_publica, l.tipo_obra, l.taxa_licenca,
      l.localizacao, l.criada_em, l.emitida_em,
      e.id as empresa_id, e.nome as empresa_nome, e.cnpj as empresa_cnpj
    FROM licencas l
    JOIN empresas e ON l.empresa_id = e.id
    WHERE 1=1
  `;
  const params = [];

  if (filtros.status) {
    query += ` AND l.status = $${params.length + 1}`;
    params.push(filtros.status);
  }

  if (filtros.empresa_id) {
    query += ` AND l.empresa_id = $${params.length + 1}`;
    params.push(filtros.empresa_id);
  }

  if (filtros.numero) {
    query += ` AND l.numero ILIKE $${params.length + 1}`;
    params.push(`%${filtros.numero}%`);
  }

  if (filtros.data_inicio && filtros.data_fim) {
    query += ` AND l.data_inicio >= $${params.length + 1} AND l.data_fim <= $${params.length + 2}`;
    params.push(filtros.data_inicio, filtros.data_fim);
  }

  query += ' ORDER BY l.criada_em DESC LIMIT 100';

  const result = await pool.query(query, params);
  return result.rows;
};

/**
 * Encontra licença por ID
 */
export const findLicencaById = async (id) => {
  const result = await pool.query(
    `SELECT * FROM licencas WHERE id = $1`,
    [id]
  );
  return result.rows[0];
};

/**
 * Encontra licença por número
 */
export const findLicencaByNumero = async (numero) => {
  const result = await pool.query(
    `SELECT * FROM licencas WHERE numero = $1`,
    [numero]
  );
  return result.rows[0];
};

/**
 * Cria nova licença
 */
export const criarLicenca = async (dados, usuarioId) => {
  const {
    empresa_id,
    numero,
    tipo_obra,
    descricao,
    local_obra,
    via_publica,
    bairro,
    responsavel_obra,
    telefone_responsavel,
    email_responsavel,
    data_inicio,
    data_fim,
    data_validade,
    restricoes,
    latitude,
    longitude,
    taxa_licenca,
    pdf_url
  } = dados;

  const result = await pool.query(
    `INSERT INTO licencas 
     (empresa_id, numero, tipo_obra, descricao, local_obra, via_publica, bairro,
      responsavel_obra, telefone_responsavel, email_responsavel,
      data_inicio, data_fim, data_validade, restricoes, localizacao, taxa_licenca, 
      pdf_url, criada_por, emitida_em, status)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, 
             ST_SetSRID(ST_Point($15, $16), 4326), $17, $18, $19, CURRENT_TIMESTAMP, 'ativa')
     RETURNING *`,
    [empresa_id, numero, tipo_obra, descricao, local_obra, via_publica, bairro,
     responsavel_obra, telefone_responsavel, email_responsavel,
     data_inicio, data_fim, data_validade, restricoes, longitude, latitude, taxa_licenca,
     pdf_url, usuarioId]
  );
  return result.rows[0];
};

/**
 * Atualiza licença
 */
export const atualizarLicenca = async (id, dados, usuarioId) => {
  const {
    tipo_obra,
    descricao,
    local_obra,
    via_publica,
    bairro,
    responsavel_obra,
    telefone_responsavel,
    email_responsavel,
    data_inicio,
    data_fim,
    data_validade,
    restricoes,
    latitude,
    longitude,
    taxa_licenca,
    status,
    pago,
    data_pagamento
  } = dados;

  let query = `
    UPDATE licencas 
    SET tipo_obra = COALESCE($1, tipo_obra),
        descricao = COALESCE($2, descricao),
        local_obra = COALESCE($3, local_obra),
        via_publica = COALESCE($4, via_publica),
        bairro = COALESCE($5, bairro),
        responsavel_obra = COALESCE($6, responsavel_obra),
        telefone_responsavel = COALESCE($7, telefone_responsavel),
        email_responsavel = COALESCE($8, email_responsavel),
        data_inicio = COALESCE($9, data_inicio),
        data_fim = COALESCE($10, data_fim),
        data_validade = COALESCE($11, data_validade),
        restricoes = COALESCE($12, restricoes),
        taxa_licenca = COALESCE($13, taxa_licenca),
        status = COALESCE($14, status),
        pago = COALESCE($15, pago),
        data_pagamento = COALESCE($16, data_pagamento),
        atualizada_por = $17,
        atualizada_em = CURRENT_TIMESTAMP
  `;

  const params = [tipo_obra, descricao, local_obra, via_publica, bairro,
                  responsavel_obra, telefone_responsavel, email_responsavel,
                  data_inicio, data_fim, data_validade, restricoes, taxa_licenca,
                  status, pago, data_pagamento, usuarioId];

  if (latitude && longitude) {
    query += `, localizacao = ST_SetSRID(ST_Point($18, $19), 4326)`;
    params.push(longitude, latitude);
  }

  query += ` WHERE id = $${params.length + 1} RETURNING *`;
  params.push(id);

  const result = await pool.query(query, params);
  return result.rows[0];
};

/**
 * Atualiza status da licença
 */
export const atualizarStatusLicenca = async (id, novoStatus) => {
  const result = await pool.query(
    `UPDATE licencas 
     SET status = $1, atualizada_em = CURRENT_TIMESTAMP
     WHERE id = $2
     RETURNING *`,
    [novoStatus, id]
  );
  return result.rows[0];
};

/**
 * Marca licenças como expiradas (para cron job)
 */
export const marcarLicencasExpiradas = async () => {
  const result = await pool.query(
    `UPDATE licencas 
     SET status = 'expirada'
     WHERE status = 'ativa' AND data_validade < CURRENT_DATE
     RETURNING id, numero, status`
  );
  return result.rows;
};

/**
 * Obtém licenças como GeoJSON para mapa
 */
export const obterLicencasGeoJSON = async (filtros = {}) => {
  let query = `
    SELECT json_build_object(
      'type', 'FeatureCollection',
      'features', json_agg(
        json_build_object(
          'type', 'Feature',
          'geometry', ST_AsGeoJSON(localizacao)::json,
          'properties', json_build_object(
            'id', id,
            'numero', numero,
            'empresa', empresa_id,
            'tipo_obra', tipo_obra,
            'local_obra', local_obra,
            'status', status,
            'data_inicio', data_inicio,
            'data_fim', data_fim,
            'data_validade', data_validade
          )
        )
      )
    ) as geojson
    FROM licencas
    WHERE 1=1
  `;

  const params = [];

  if (filtros.status) {
    query += ` AND status = $${params.length + 1}`;
    params.push(filtros.status);
  }

  if (filtros.empresa_id) {
    query += ` AND empresa_id = $${params.length + 1}`;
    params.push(filtros.empresa_id);
  }

  const result = await pool.query(query, params);
  return result.rows[0]?.geojson || { type: 'FeatureCollection', features: [] };
};

/**
 * Deleta licença (soft delete)
 */
export const deletarLicenca = async (id) => {
  const result = await pool.query(
    'UPDATE licencas SET status = $1 WHERE id = $2 RETURNING id',
    ['cancelada', id]
  );
  return result.rows[0];
};
