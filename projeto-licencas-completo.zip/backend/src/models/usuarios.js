import pool from '../config/database.js';

// ============================================================================
// USUÁRIOS
// ============================================================================

/**
 * Encontra usuário por email
 */
export const findUsuarioByEmail = async (email) => {
  const result = await pool.query(
    'SELECT * FROM usuarios WHERE email = $1',
    [email]
  );
  return result.rows[0];
};

/**
 * Encontra usuário por ID
 */
export const findUsuarioById = async (id) => {
  const result = await pool.query(
    'SELECT id, nome, email, role, ativo, telefone, criado_em, ultimo_login FROM usuarios WHERE id = $1',
    [id]
  );
  return result.rows[0];
};

/**
 * Lista todos os usuários (admin only)
 */
export const listarUsuarios = async () => {
  const result = await pool.query(
    'SELECT id, nome, email, role, ativo, telefone, criado_em, ultimo_login FROM usuarios ORDER BY criado_em DESC'
  );
  return result.rows;
};

/**
 * Cria novo usuário
 */
export const criarUsuario = async (nome, email, senhaHash, role = 'operador', telefone = null) => {
  const result = await pool.query(
    `INSERT INTO usuarios (nome, email, senha_hash, role, telefone, criado_em, atualizado_em)
     VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
     RETURNING id, nome, email, role, ativo, telefone, criado_em`,
    [nome, email, senhaHash, role, telefone]
  );
  return result.rows[0];
};

/**
 * Atualiza usuário
 */
export const atualizarUsuario = async (id, dados) => {
  const { nome, email, telefone, role, ativo } = dados;
  const result = await pool.query(
    `UPDATE usuarios 
     SET nome = COALESCE($1, nome),
         email = COALESCE($2, email),
         telefone = COALESCE($3, telefone),
         role = COALESCE($4, role),
         ativo = COALESCE($5, ativo),
         atualizado_em = CURRENT_TIMESTAMP
     WHERE id = $6
     RETURNING id, nome, email, role, ativo, telefone, criado_em, ultimo_login`,
    [nome, email, telefone, role, ativo, id]
  );
  return result.rows[0];
};

/**
 * Atualiza último login
 */
export const atualizarUltimoLogin = async (id) => {
  await pool.query(
    'UPDATE usuarios SET ultimo_login = CURRENT_TIMESTAMP WHERE id = $1',
    [id]
  );
};

/**
 * Deleta usuário (soft delete)
 */
export const deletarUsuario = async (id) => {
  const result = await pool.query(
    'UPDATE usuarios SET ativo = false WHERE id = $1 RETURNING id',
    [id]
  );
  return result.rows[0];
};

// ============================================================================
// EMPRESAS
// ============================================================================

/**
 * Lista todas as empresas
 */
export const listarEmpresas = async (filtros = {}) => {
  let query = 'SELECT * FROM empresas WHERE ativo = true';
  const params = [];

  if (filtros.nome) {
    query += ` AND nome ILIKE $${params.length + 1}`;
    params.push(`%${filtros.nome}%`);
  }

  if (filtros.cnpj) {
    query += ` AND cnpj = $${params.length + 1}`;
    params.push(filtros.cnpj);
  }

  query += ' ORDER BY nome ASC';

  const result = await pool.query(query, params);
  return result.rows;
};

/**
 * Encontra empresa por ID
 */
export const findEmpresaById = async (id) => {
  const result = await pool.query(
    'SELECT * FROM empresas WHERE id = $1',
    [id]
  );
  return result.rows[0];
};

/**
 * Encontra empresa por CNPJ
 */
export const findEmpresaByCNPJ = async (cnpj) => {
  const result = await pool.query(
    'SELECT * FROM empresas WHERE cnpj = $1',
    [cnpj]
  );
  return result.rows[0];
};

/**
 * Cria nova empresa
 */
export const criarEmpresa = async (dados, usuarioId) => {
  const {
    nome,
    cnpj,
    telefone,
    email,
    endereco,
    bairro,
    representante,
    telefone_representante,
    email_representante
  } = dados;

  const result = await pool.query(
    `INSERT INTO empresas 
     (nome, cnpj, telefone, email, endereco, bairro, representante, telefone_representante, email_representante, criada_por, criada_em)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, CURRENT_TIMESTAMP)
     RETURNING *`,
    [nome, cnpj, telefone, email, endereco, bairro, representante, telefone_representante, email_representante, usuarioId]
  );
  return result.rows[0];
};

/**
 * Atualiza empresa
 */
export const atualizarEmpresa = async (id, dados, usuarioId) => {
  const {
    nome,
    telefone,
    email,
    endereco,
    bairro,
    representante,
    telefone_representante,
    email_representante,
    ativo
  } = dados;

  const result = await pool.query(
    `UPDATE empresas 
     SET nome = COALESCE($1, nome),
         telefone = COALESCE($2, telefone),
         email = COALESCE($3, email),
         endereco = COALESCE($4, endereco),
         bairro = COALESCE($5, bairro),
         representante = COALESCE($6, representante),
         telefone_representante = COALESCE($7, telefone_representante),
         email_representante = COALESCE($8, email_representante),
         ativo = COALESCE($9, ativo),
         atualizada_por = $10,
         atualizada_em = CURRENT_TIMESTAMP
     WHERE id = $11
     RETURNING *`,
    [nome, telefone, email, endereco, bairro, representante, telefone_representante, email_representante, ativo, usuarioId, id]
  );
  return result.rows[0];
};

/**
 * Deleta empresa (soft delete)
 */
export const deletarEmpresa = async (id) => {
  const result = await pool.query(
    'UPDATE empresas SET ativo = false WHERE id = $1 RETURNING id',
    [id]
  );
  return result.rows[0];
};
