import pool from '../config/database.js';

// ============================================================================
// DENÚNCIAS
// ============================================================================

/**
 * Lista denúncias com filtros
 */
export const listarDenuncias = async (filtros = {}) => {
  let query = `
    SELECT 
      d.id, d.titulo, d.descricao, d.canal, d.status, d.endereco,
      d.localizacao, d.foto_url, d.criada_em,
      d.licenca_relacionada_id,
      l.numero as licenca_numero
    FROM denuncias d
    LEFT JOIN licencas l ON d.licenca_relacionada_id = l.id
    WHERE 1=1
  `;
  const params = [];

  if (filtros.status) {
    query += ` AND d.status = $${params.length + 1}`;
    params.push(filtros.status);
  }

  if (filtros.canal) {
    query += ` AND d.canal = $${params.length + 1}`;
    params.push(filtros.canal);
  }

  if (filtros.licenca_id) {
    query += ` AND d.licenca_relacionada_id = $${params.length + 1}`;
    params.push(filtros.licenca_id);
  }

  query += ' ORDER BY d.criada_em DESC LIMIT 100';

  const result = await pool.query(query, params);
  return result.rows;
};

/**
 * Encontra denúncia por ID
 */
export const findDenunciaById = async (id) => {
  const result = await pool.query(
    `SELECT * FROM denuncias WHERE id = $1`,
    [id]
  );
  return result.rows[0];
};

/**
 * Cria nova denúncia
 */
export const criarDenuncia = async (dados, usuarioId) => {
  const {
    titulo,
    descricao,
    canal,
    endereco,
    latitude,
    longitude,
    foto_url,
    licenca_relacionada_id
  } = dados;

  const result = await pool.query(
    `INSERT INTO denuncias 
     (titulo, descricao, canal, endereco, localizacao, foto_url, 
      licenca_relacionada_id, status, criada_por)
     VALUES ($1, $2, $3, $4, ST_SetSRID(ST_Point($5, $6), 4326), 
             $7, $8, 'aberta', $9)
     RETURNING *`,
    [titulo, descricao, canal, endereco, longitude, latitude, foto_url, 
     licenca_relacionada_id || null, usuarioId]
  );
  return result.rows[0];
};

/**
 * Atualiza denúncia
 */
export const atualizarDenuncia = async (id, dados, usuarioId) => {
  const {
    titulo,
    descricao,
    canal,
    endereco,
    latitude,
    longitude,
    foto_url,
    status,
    observacoes_investigacao,
    licenca_relacionada_id
  } = dados;

  let query = `
    UPDATE denuncias 
    SET titulo = COALESCE($1, titulo),
        descricao = COALESCE($2, descricao),
        canal = COALESCE($3, canal),
        endereco = COALESCE($4, endereco),
        foto_url = COALESCE($5, foto_url),
        status = COALESCE($6, status),
        observacoes_investigacao = COALESCE($7, observacoes_investigacao),
        licenca_relacionada_id = COALESCE($8, licenca_relacionada_id),
        atualizada_por = $9,
        atualizada_em = CURRENT_TIMESTAMP
  `;

  const params = [titulo, descricao, canal, endereco, foto_url, status, 
                  observacoes_investigacao, licenca_relacionada_id, usuarioId];

  if (latitude && longitude) {
    query += `, localizacao = ST_SetSRID(ST_Point($10, $11), 4326)`;
    params.push(longitude, latitude);
  }

  query += ` WHERE id = $${params.length + 1} RETURNING *`;
  params.push(id);

  const result = await pool.query(query, params);
  return result.rows[0];
};

/**
 * Relaciona denúncia com licença
 */
export const relacionarDenunciaComLicenca = async (denunciaId, licencaId) => {
  const result = await pool.query(
    `UPDATE denuncias 
     SET licenca_relacionada_id = $1, atualizada_em = CURRENT_TIMESTAMP
     WHERE id = $2
     RETURNING *`,
    [licencaId, denunciaId]
  );
  return result.rows[0];
};

/**
 * Obtém denúncias como GeoJSON para mapa
 */
export const obterDenunciasGeoJSON = async (filtros = {}) => {
  let query = `
    SELECT json_build_object(
      'type', 'FeatureCollection',
      'features', json_agg(
        json_build_object(
          'type', 'Feature',
          'geometry', ST_AsGeoJSON(localizacao)::json,
          'properties', json_build_object(
            'id', id,
            'titulo', titulo,
            'descricao', descricao,
            'canal', canal,
            'status', status,
            'licenca_id', licenca_relacionada_id,
            'criada_em', criada_em
          )
        )
      )
    ) as geojson
    FROM denuncias
    WHERE 1=1
  `;

  const params = [];

  if (filtros.status) {
    query += ` AND status = $${params.length + 1}`;
    params.push(filtros.status);
  }

  if (filtros.licenca_id) {
    query += ` AND licenca_relacionada_id = $${params.length + 1}`;
    params.push(filtros.licenca_id);
  }

  const result = await pool.query(query, params);
  return result.rows[0]?.geojson || { type: 'FeatureCollection', features: [] };
};

// ============================================================================
// ANÁLISE PÓS-OBRA
// ============================================================================

/**
 * Lista análises por licença
 */
export const listarAnalisesPorLicenca = async (licencaId) => {
  const result = await pool.query(
    `SELECT * FROM analise_pos_obra WHERE licenca_id = $1 ORDER BY criada_em DESC`,
    [licencaId]
  );
  return result.rows;
};

/**
 * Encontra análise por ID
 */
export const findAnaliseById = async (id) => {
  const result = await pool.query(
    `SELECT * FROM analise_pos_obra WHERE id = $1`,
    [id]
  );
  return result.rows[0];
};

/**
 * Cria nova análise pós-obra
 */
export const criarAnalise = async (dados, usuarioId) => {
  const {
    licenca_id,
    data_conclusao,
    estado_local,
    descricao_estado,
    foto_antes_url,
    foto_depois_url,
    observacoes,
    responsavel_analise
  } = dados;

  const result = await pool.query(
    `INSERT INTO analise_pos_obra 
     (licenca_id, data_conclusao, estado_local, descricao_estado,
      foto_antes_url, foto_depois_url, observacoes, responsavel_analise, criada_por)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     RETURNING *`,
    [licenca_id, data_conclusao, estado_local, descricao_estado,
     foto_antes_url, foto_depois_url, observacoes, responsavel_analise, usuarioId]
  );
  return result.rows[0];
};

/**
 * Atualiza análise
 */
export const atualizarAnalise = async (id, dados, usuarioId) => {
  const {
    estado_local,
    descricao_estado,
    foto_antes_url,
    foto_depois_url,
    observacoes,
    responsavel_analise
  } = dados;

  const result = await pool.query(
    `UPDATE analise_pos_obra 
     SET estado_local = COALESCE($1, estado_local),
         descricao_estado = COALESCE($2, descricao_estado),
         foto_antes_url = COALESCE($3, foto_antes_url),
         foto_depois_url = COALESCE($4, foto_depois_url),
         observacoes = COALESCE($5, observacoes),
         responsavel_analise = COALESCE($6, responsavel_analise)
     WHERE id = $7
     RETURNING *`,
    [estado_local, descricao_estado, foto_antes_url, foto_depois_url, 
     observacoes, responsavel_analise, id]
  );
  return result.rows[0];
};

/**
 * Deleta análise
 */
export const deletarAnalise = async (id) => {
  const result = await pool.query(
    'DELETE FROM analise_pos_obra WHERE id = $1 RETURNING id',
    [id]
  );
  return result.rows[0];
};
