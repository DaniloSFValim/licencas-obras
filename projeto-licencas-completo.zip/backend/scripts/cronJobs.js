import schedule from 'node-schedule';
import { marcarLicencasExpiradas } from './src/models/licencas.js';

/**
 * Agenda tarefa para verificar licenças expiradas
 * Executa todos os dias às 2:00 AM
 */
export const iniciarCronJobs = () => {
  console.log('📅 Iniciando cron jobs...');

  // Verifica licenças expiradas todos os dias às 2:00 AM
  schedule.scheduleJob('0 2 * * *', async () => {
    try {
      console.log('🔄 Verificando licenças expiradas...');
      const licencasExpiradas = await marcarLicencasExpiradas();
      
      if (licencasExpiradas.length > 0) {
        console.log(`✅ ${licencasExpiradas.length} licença(s) marcada(s) como expirada(s):`);
        licencasExpiradas.forEach(licenca => {
          console.log(`   - ${licenca.numero}`);
        });
      } else {
        console.log('ℹ️  Nenhuma licença expirada encontrada');
      }
    } catch (error) {
      console.error('❌ Erro ao verificar licenças expiradas:', error);
    }
  });

  console.log('✅ Cron jobs iniciados com sucesso');
  console.log('   - Verificação de expiração: Todos os dias às 2:00 AM');
};

/**
 * Executa verificação de expiração agora (para testes)
 */
export const verificarExpiracaoAgora = async () => {
  try {
    console.log('🔄 Executando verificação de expiração imediatamente...');
    const licencasExpiradas = await marcarLicencasExpiradas();
    
    if (licencasExpiradas.length > 0) {
      console.log(`✅ ${licencasExpiradas.length} licença(s) marcada(s) como expirada(s)`);
    } else {
      console.log('ℹ️  Nenhuma licença expirada');
    }
    
    return licencasExpiradas;
  } catch (error) {
    console.error('❌ Erro:', error);
    throw error;
  }
};
