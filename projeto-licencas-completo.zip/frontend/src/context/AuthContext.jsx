import React, { createContext, useContext, useState, useEffect } from 'react';
import { authService } from '../services/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [usuario, setUsuario] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState(null);

  // Verifica se usuário está logado ao carregar
  useEffect(() => {
    const verificarAutenticacao = async () => {
      if (token) {
        try {
          const response = await authService.getMe();
          setUsuario(response.data.dados);
          setErro(null);
        } catch (error) {
          console.error('Erro ao verificar autenticação:', error);
          localStorage.removeItem('token');
          setToken(null);
          setUsuario(null);
        }
      }
      setLoading(false);
    };

    verificarAutenticacao();
  }, [token]);

  const login = async (email, senha) => {
    try {
      setLoading(true);
      setErro(null);
      const response = await authService.login(email, senha);
      const { token, usuario } = response.data.dados;
      
      localStorage.setItem('token', token);
      setToken(token);
      setUsuario(usuario);
      
      return true;
    } catch (error) {
      const mensagem = error.response?.data?.mensagem || 'Erro ao fazer login';
      setErro(mensagem);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUsuario(null);
    setErro(null);
  };

  const estaAutenticado = !!token && !!usuario;
  const ehAdmin = usuario?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        usuario,
        token,
        loading,
        erro,
        login,
        logout,
        estaAutenticado,
        ehAdmin
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de AuthProvider');
  }
  return context;
};
