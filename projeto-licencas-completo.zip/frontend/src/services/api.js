import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Interceptor para adicionar token JWT
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Interceptor para tratar erros
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// ============================================================================
// AUTH
// ============================================================================

export const authService = {
  login: (email, senha) =>
    api.post('/auth/login', { email, senha }),
  
  refreshToken: () =>
    api.post('/auth/refresh-token'),
  
  getMe: () =>
    api.get('/auth/me'),
  
  logout: () =>
    api.post('/auth/logout')
};

// ============================================================================
// EMPRESAS
// ============================================================================

export const empresasService = {
  listar: (filtros = {}) =>
    api.get('/empresas', { params: filtros }),
  
  obterPorId: (id) =>
    api.get(`/empresas/${id}`),
  
  criar: (dados) =>
    api.post('/empresas', dados),
  
  atualizar: (id, dados) =>
    api.put(`/empresas/${id}`, dados),
  
  deletar: (id) =>
    api.delete(`/empresas/${id}`)
};

// ============================================================================
// LICENÇAS
// ============================================================================

export const licencasService = {
  listar: (filtros = {}) =>
    api.get('/licencas', { params: filtros }),
  
  obterPorId: (id) =>
    api.get(`/licencas/${id}`),
  
  criar: (dados) =>
    api.post('/licencas', dados),
  
  atualizar: (id, dados) =>
    api.put(`/licencas/${id}`, dados),
  
  atualizarStatus: (id, status) =>
    api.patch(`/licencas/${id}/status`, { status }),
  
  obterGeoJSON: (filtros = {}) =>
    api.get('/licencas/geojson', { params: filtros }),
  
  deletar: (id) =>
    api.delete(`/licencas/${id}`)
};

export default api;
