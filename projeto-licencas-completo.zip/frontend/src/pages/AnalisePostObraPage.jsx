import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Plus, Edit2, Trash2, FileText } from 'lucide-react';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api'
});

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

const analiseService = {
  listarPorLicenca: (licencaId) =>
    api.get(`/analise/licenca/${licencaId}`),
  
  criar: (dados) =>
    api.post('/analise', dados),
  
  atualizar: (id, dados) =>
    api.put(`/analise/${id}`, dados),
  
  deletar: (id) =>
    api.delete(`/analise/${id}`)
};

const licencasService = {
  listar: () =>
    api.get('/licencas')
};

export const AnalisePostObraPage = () => {
  const [licencas, setLicencas] = useState([]);
  const [analisesSelecionadas, setAnalisesSelecionadas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState('');
  const [licencaSelecionada, setLicencaSelecionada] = useState('');
  const [modalAberto, setModalAberto] = useState(false);
  const [formulario, setFormulario] = useState({
    licenca_id: '',
    data_conclusao: '',
    estado_local: '',
    descricao_estado: '',
    foto_antes_url: '',
    foto_depois_url: '',
    observacoes: '',
    responsavel_analise: ''
  });
  const [editandoId, setEditandoId] = useState(null);

  // Carrega licenças
  useEffect(() => {
    carregarLicencas();
  }, []);

  // Carrega análises quando licença é selecionada
  useEffect(() => {
    if (licencaSelecionada) {
      carregarAnalises();
    }
  }, [licencaSelecionada]);

  const carregarLicencas = async () => {
    try {
      setLoading(true);
      const response = await licencasService.listar();
      setLicencas(response.data.dados.licencas || []);
    } catch (error) {
      console.error('Erro ao carregar licenças:', error);
    } finally {
      setLoading(false);
    }
  };

  const carregarAnalises = async () => {
    try {
      const response = await analiseService.listarPorLicenca(licencaSelecionada);
      setAnalisesSelecionadas(response.data.dados.analises || []);
    } catch (error) {
      console.error('Erro ao carregar análises:', error);
      setAnalisesSelecionadas([]);
    }
  };

  const abrirModal = (analise = null) => {
    if (analise) {
      setFormulario(analise);
      setEditandoId(analise.id);
    } else {
      setFormulario({
        licenca_id: licencaSelecionada,
        data_conclusao: '',
        estado_local: '',
        descricao_estado: '',
        foto_antes_url: '',
        foto_depois_url: '',
        observacoes: '',
        responsavel_analise: ''
      });
      setEditandoId(null);
    }
    setModalAberto(true);
  };

  const fecharModal = () => {
    setModalAberto(false);
    setEditandoId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editandoId) {
        await analiseService.atualizar(editandoId, formulario);
      } else {
        await analiseService.criar(formulario);
      }
      fecharModal();
      carregarAnalises();
    } catch (error) {
      setErro(error.response?.data?.mensagem || 'Erro ao salvar análise');
    }
  };

  const handleDeletar = async (id) => {
    if (!window.confirm('Tem certeza que deseja deletar essa análise?')) return;

    try {
      await analiseService.deletar(id);
      carregarAnalises();
    } catch (error) {
      setErro('Erro ao deletar análise');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormulario(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const obterNomeLicenca = (licencaId) => {
    const licenca = licencas.find(l => l.id === parseInt(licencaId));
    return licenca ? licenca.numero : 'N/A';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Análise Pós-Obra</h1>
        <p className="text-gray-600 mt-1">Relatórios de conclusão de obras autorizadas</p>
      </div>

      {/* Erros */}
      {erro && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-700 text-sm">{erro}</p>
        </div>
      )}

      {/* Seleção de Licença */}
      <div className="card">
        <label className="label font-semibold">Selecione uma licença para visualizar análises</label>
        {loading ? (
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
        ) : (
          <select
            className="input-field"
            value={licencaSelecionada}
            onChange={(e) => setLicencaSelecionada(e.target.value)}
          >
            <option value="">-- Selecione uma licença --</option>
            {licencas
              .filter(l => l.status !== 'cancelada')
              .map(licenca => (
                <option key={licenca.id} value={licenca.id}>
                  {licenca.numero} - {licenca.tipo_obra} ({licenca.status})
                </option>
              ))}
          </select>
        )}
      </div>

      {/* Botão Nova Análise */}
      {licencaSelecionada && (
        <div className="flex justify-end">
          <button
            onClick={() => abrirModal()}
            className="btn-primary flex items-center gap-2"
          >
            <Plus className="h-5 w-5" />
            Nova Análise
          </button>
        </div>
      )}

      {/* Tabela de Análises */}
      {licencaSelecionada && (
        <div className="card overflow-x-auto">
          <h3 className="font-semibold text-gray-800 mb-4">
            Análises da Licença {obterNomeLicenca(licencaSelecionada)}
          </h3>
          <table className="w-full text-sm">
            <thead className="border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Data Conclusão</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Estado Local</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Responsável</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Fotos</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-700">Ações</th>
              </tr>
            </thead>
            <tbody>
              {analisesSelecionadas.length === 0 ? (
                <tr>
                  <td colSpan="5" className="text-center py-8 text-gray-600">
                    Nenhuma análise encontrada para esta licença
                  </td>
                </tr>
              ) : (
                analisesSelecionadas.map(analise => (
                  <tr key={analise.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      {new Date(analise.data_conclusao).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">
                        {analise.estado_local}
                      </span>
                    </td>
                    <td className="py-3 px-4">{analise.responsavel_analise || '-'}</td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        {analise.foto_antes_url && (
                          <a
                            href={analise.foto_antes_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline text-xs"
                          >
                            Antes
                          </a>
                        )}
                        {analise.foto_depois_url && (
                          <a
                            href={analise.foto_depois_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline text-xs"
                          >
                            Depois
                          </a>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => abrirModal(analise)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded"
                          title="Editar"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeletar(analise.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded"
                          title="Deletar"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      {modalAberto && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            {/* Header Modal */}
            <div className="p-6 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white">
              <h2 className="text-xl font-semibold text-gray-800">
                {editandoId ? 'Editar Análise' : 'Nova Análise Pós-Obra'}
              </h2>
              <button
                onClick={fecharModal}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>

            {/* Formulário */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="label">Data de Conclusão *</label>
                <input
                  type="date"
                  name="data_conclusao"
                  className="input-field"
                  value={formulario.data_conclusao}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div>
                <label className="label">Estado Local *</label>
                <select
                  name="estado_local"
                  className="input-field"
                  value={formulario.estado_local}
                  onChange={handleInputChange}
                  required
                >
                  <option value="">Selecione</option>
                  <option value="satisfatorio">Satisfatório</option>
                  <option value="danificado">Danificado</option>
                  <option value="incompleto">Incompleto</option>
                </select>
              </div>

              <div>
                <label className="label">Descrição do Estado</label>
                <textarea
                  name="descricao_estado"
                  className="input-field"
                  rows="3"
                  value={formulario.descricao_estado}
                  onChange={handleInputChange}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label">URL Foto Antes</label>
                  <input
                    type="url"
                    name="foto_antes_url"
                    className="input-field"
                    value={formulario.foto_antes_url}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <label className="label">URL Foto Depois</label>
                  <input
                    type="url"
                    name="foto_depois_url"
                    className="input-field"
                    value={formulario.foto_depois_url}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div>
                <label className="label">Responsável pela Análise</label>
                <input
                  type="text"
                  name="responsavel_analise"
                  className="input-field"
                  value={formulario.responsavel_analise}
                  onChange={handleInputChange}
                />
              </div>

              <div>
                <label className="label">Observações</label>
                <textarea
                  name="observacoes"
                  className="input-field"
                  rows="3"
                  value={formulario.observacoes}
                  onChange={handleInputChange}
                />
              </div>

              {/* Botões */}
              <div className="flex gap-4 pt-6 border-t border-gray-200">
                <button
                  type="submit"
                  className="flex-1 btn-primary"
                >
                  {editandoId ? 'Atualizar' : 'Criar'} Análise
                </button>
                <button
                  type="button"
                  onClick={fecharModal}
                  className="flex-1 btn-secondary"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
