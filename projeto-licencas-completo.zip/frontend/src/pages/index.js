import React from 'react';
import { AlertCircle } from 'lucide-react';

// Importa as páginas reais
export { DenunciasPage } from './DenunciasPage';
export { AnalisePostObraPage } from './AnalisePostObraPage';

export const UsuariosPage = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Gestão de Usuários</h1>
        <p className="text-gray-600 mt-1">Controle de acesso (Admin only)</p>
      </div>

      <div className="card text-center py-12">
        <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600 font-medium">
          Funcionalidade em desenvolvimento
        </p>
        <p className="text-gray-500 text-sm mt-2">
          Gestão de usuários admin e operadores será implementada em breve
        </p>
      </div>
    </div>
  );
};
