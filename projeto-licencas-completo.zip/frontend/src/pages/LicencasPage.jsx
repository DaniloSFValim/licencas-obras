import React, { useState, useEffect } from 'react';
import { licencasService, empresasService } from '../services/api';
import { Plus, Edit2, Trash2, Download } from 'lucide-react';

export const LicencasPage = () => {
  const [licencas, setLicencas] = useState([]);
  const [empresas, setEmpresas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState('');
  const [statusFiltro, setStatusFiltro] = useState('');
  const [modalAberto, setModalAberto] = useState(false);
  const [formulario, setFormulario] = useState({
    empresa_id: '',
    tipo_obra: '',
    descricao: '',
    local_obra: '',
    via_publica: '',
    bairro: '',
    responsavel_obra: '',
    telefone_responsavel: '',
    email_responsavel: '',
    data_inicio: '',
    data_fim: '',
    data_validade: '',
    restricoes: '',
    latitude: '',
    longitude: '',
    taxa_licenca: ''
  });
  const [editandoId, setEditandoId] = useState(null);

  // Carrega dados
  useEffect(() => {
    carregarDados();
  }, [statusFiltro]);

  const carregarDados = async () => {
    try {
      setLoading(true);
      setErro('');
      const [resLicencas, resEmpresas] = await Promise.all([
        licencasService.listar({ status: statusFiltro || undefined }),
        empresasService.listar()
      ]);
      setLicencas(resLicencas.data.dados.licencas || []);
      setEmpresas(resEmpresas.data.dados.empresas || []);
    } catch (error) {
      setErro('Erro ao carregar dados');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const abrirModal = (licenca = null) => {
    if (licenca) {
      setFormulario(licenca);
      setEditandoId(licenca.id);
    } else {
      setFormulario({
        empresa_id: '',
        tipo_obra: '',
        descricao: '',
        local_obra: '',
        via_publica: '',
        bairro: '',
        responsavel_obra: '',
        telefone_responsavel: '',
        email_responsavel: '',
        data_inicio: '',
        data_fim: '',
        data_validade: '',
        restricoes: '',
        latitude: '',
        longitude: '',
        taxa_licenca: ''
      });
      setEditandoId(null);
    }
    setModalAberto(true);
  };

  const fecharModal = () => {
    setModalAberto(false);
    setEditandoId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const dados = {
        ...formulario,
        latitude: parseFloat(formulario.latitude),
        longitude: parseFloat(formulario.longitude),
        empresa_id: parseInt(formulario.empresa_id),
        taxa_licenca: parseFloat(formulario.taxa_licenca) || null
      };

      if (editandoId) {
        await licencasService.atualizar(editandoId, dados);
      } else {
        await licencasService.criar(dados);
      }
      fecharModal();
      carregarDados();
    } catch (error) {
      setErro(error.response?.data?.mensagem || 'Erro ao salvar licença');
    }
  };

  const handleDeletar = async (id) => {
    if (!window.confirm('Tem certeza que deseja cancelar essa licença?')) return;

    try {
      await licencasService.deletar(id);
      carregarDados();
    } catch (error) {
      setErro('Erro ao deletar licença');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormulario(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const obterNomeEmpresa = (empresaId) => {
    return empresas.find(e => e.id === empresaId)?.nome || '-';
  };

  const obterCorStatus = (status) => {
    const cores = {
      ativa: 'bg-green-100 text-green-800',
      expirada: 'bg-gray-100 text-gray-800',
      concluida: 'bg-blue-100 text-blue-800',
      cancelada: 'bg-red-100 text-red-800'
    };
    return cores[status] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Licenças</h1>
          <p className="text-gray-600 mt-1">Gestão de licenças para obras</p>
        </div>
        <button
          onClick={() => abrirModal()}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="h-5 w-5" />
          Nova Licença
        </button>
      </div>

      {/* Erros */}
      {erro && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-700 text-sm">{erro}</p>
        </div>
      )}

      {/* Filtros */}
      <div className="card">
        <div className="flex items-center gap-4">
          <label className="font-medium text-gray-700">Status:</label>
          <select
            className="input-field"
            value={statusFiltro}
            onChange={(e) => setStatusFiltro(e.target.value)}
          >
            <option value="">Todas</option>
            <option value="ativa">Ativa</option>
            <option value="expirada">Expirada</option>
            <option value="concluida">Concluída</option>
            <option value="cancelada">Cancelada</option>
          </select>
        </div>
      </div>

      {/* Tabela */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Número</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Empresa</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Tipo de Obra</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Local</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-700">Ações</th>
              </tr>
            </thead>
            <tbody>
              {licencas.length === 0 ? (
                <tr>
                  <td colSpan="6" className="text-center py-8 text-gray-600">
                    Nenhuma licença encontrada
                  </td>
                </tr>
              ) : (
                licencas.map(licenca => (
                  <tr key={licenca.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-4 font-mono text-xs">{licenca.numero}</td>
                    <td className="py-3 px-4">{obterNomeEmpresa(licenca.empresa_id)}</td>
                    <td className="py-3 px-4">{licenca.tipo_obra}</td>
                    <td className="py-3 px-4 truncate">{licenca.local_obra}</td>
                    <td className="py-3 px-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${obterCorStatus(licenca.status)}`}>
                        {licenca.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        {licenca.pdf_url && (
                          <a
                            href={licenca.pdf_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 text-green-600 hover:bg-green-50 rounded"
                            title="Baixar PDF"
                          >
                            <Download className="h-4 w-4" />
                          </a>
                        )}
                        <button
                          onClick={() => abrirModal(licenca)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded"
                          title="Editar"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeletar(licenca.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded"
                          title="Deletar"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      {modalAberto && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            {/* Header Modal */}
            <div className="p-6 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white">
              <h2 className="text-xl font-semibold text-gray-800">
                {editandoId ? 'Editar Licença' : 'Nova Licença'}
              </h2>
              <button
                onClick={fecharModal}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>

            {/* Formulário */}
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              {/* Seção 1: Empresa */}
              <div>
                <h3 className="font-semibold text-gray-800 mb-4">Informações da Empresa</h3>
                <div>
                  <label className="label">Empresa *</label>
                  <select
                    name="empresa_id"
                    className="input-field"
                    value={formulario.empresa_id}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Selecione uma empresa</option>
                    {empresas.map(empresa => (
                      <option key={empresa.id} value={empresa.id}>
                        {empresa.nome} ({empresa.cnpj})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Seção 2: Obra */}
              <div>
                <h3 className="font-semibold text-gray-800 mb-4">Informações da Obra</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="label">Tipo de Obra *</label>
                    <input
                      type="text"
                      name="tipo_obra"
                      className="input-field"
                      value={formulario.tipo_obra}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <label className="label">Local da Obra *</label>
                    <input
                      type="text"
                      name="local_obra"
                      className="input-field"
                      value={formulario.local_obra}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className="label">Via Pública</label>
                    <input
                      type="text"
                      name="via_publica"
                      className="input-field"
                      value={formulario.via_publica}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div>
                    <label className="label">Bairro</label>
                    <input
                      type="text"
                      name="bairro"
                      className="input-field"
                      value={formulario.bairro}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                <div className="mt-4">
                  <label className="label">Descrição</label>
                  <textarea
                    name="descricao"
                    className="input-field"
                    rows="3"
                    value={formulario.descricao}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              {/* Seção 3: Responsável */}
              <div>
                <h3 className="font-semibold text-gray-800 mb-4">Responsável pela Obra</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="label">Nome *</label>
                    <input
                      type="text"
                      name="responsavel_obra"
                      className="input-field"
                      value={formulario.responsavel_obra}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <label className="label">Telefone</label>
                    <input
                      type="tel"
                      name="telefone_responsavel"
                      className="input-field"
                      value={formulario.telefone_responsavel}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                <div className="mt-4">
                  <label className="label">Email</label>
                  <input
                    type="email"
                    name="email_responsavel"
                    className="input-field"
                    value={formulario.email_responsavel}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              {/* Seção 4: Datas e Localização */}
              <div>
                <h3 className="font-semibold text-gray-800 mb-4">Datas e Localização</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="label">Data de Início *</label>
                    <input
                      type="date"
                      name="data_inicio"
                      className="input-field"
                      value={formulario.data_inicio}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <label className="label">Data de Término *</label>
                    <input
                      type="date"
                      name="data_fim"
                      className="input-field"
                      value={formulario.data_fim}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <label className="label">Data de Validade *</label>
                    <input
                      type="date"
                      name="data_validade"
                      className="input-field"
                      value={formulario.data_validade}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className="label">Latitude *</label>
                    <input
                      type="number"
                      step="0.000001"
                      name="latitude"
                      className="input-field"
                      value={formulario.latitude}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <label className="label">Longitude *</label>
                    <input
                      type="number"
                      step="0.000001"
                      name="longitude"
                      className="input-field"
                      value={formulario.longitude}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Seção 5: Restrições e Taxa */}
              <div>
                <h3 className="font-semibold text-gray-800 mb-4">Restrições e Taxas</h3>
                <div className="mb-4">
                  <label className="label">Restrições (horários, interdições, etc)</label>
                  <textarea
                    name="restricoes"
                    className="input-field"
                    rows="3"
                    value={formulario.restricoes}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <label className="label">Taxa de Licença (R$)</label>
                  <input
                    type="number"
                    step="0.01"
                    name="taxa_licenca"
                    className="input-field"
                    value={formulario.taxa_licenca}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              {/* Botões */}
              <div className="flex gap-4 pt-6 border-t border-gray-200">
                <button
                  type="submit"
                  className="flex-1 btn-primary"
                >
                  {editandoId ? 'Atualizar' : 'Emitir'} Licença
                </button>
                <button
                  type="button"
                  onClick={fecharModal}
                  className="flex-1 btn-secondary"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
