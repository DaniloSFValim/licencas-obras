import React, { useState, useEffect } from 'react';
import { empresasService, licencasService } from '../services/api';
import { Building2, FileText, AlertCircle, TrendingUp } from 'lucide-react';

export const DashboardPage = () => {
  const [dados, setDados] = useState({
    totalEmpresas: 0,
    totalLicencas: 0,
    licencasAtivas: 0,
    denunciasAbertas: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const carregarDados = async () => {
      try {
        const [empresas, licencas] = await Promise.all([
          empresasService.listar(),
          licencasService.listar({ status: 'ativa' })
        ]);

        setDados({
          totalEmpresas: empresas.data.dados.total || 0,
          totalLicencas: licencas.data.dados.total || 0,
          licencasAtivas: licencas.data.dados.total || 0,
          denunciasAbertas: 0
        });
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
      } finally {
        setLoading(false);
      }
    };

    carregarDados();
  }, []);

  const cartoes = [
    {
      titulo: 'Empresas Cadastradas',
      valor: dados.totalEmpresas,
      icon: Building2,
      cor: 'blue'
    },
    {
      titulo: 'Licenças Emitidas',
      valor: dados.totalLicencas,
      icon: FileText,
      cor: 'green'
    },
    {
      titulo: 'Licenças Ativas',
      valor: dados.licencasAtivas,
      icon: TrendingUp,
      cor: 'purple'
    },
    {
      titulo: 'Denúncias Abertas',
      valor: dados.denunciasAbertas,
      icon: AlertCircle,
      cor: 'red'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Dashboard</h1>
        <p className="text-gray-600 mt-1">Bem-vindo ao sistema de licenças de Niterói</p>
      </div>

      {/* Cards de Estatísticas */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {cartoes.map((cartao, index) => {
            const Icon = cartao.icon;
            const corMap = {
              blue: 'bg-blue-50 text-blue-600',
              green: 'bg-green-50 text-green-600',
              purple: 'bg-purple-50 text-purple-600',
              red: 'bg-red-50 text-red-600'
            };

            return (
              <div key={index} className="card hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-gray-600 text-sm font-medium">{cartao.titulo}</p>
                    <p className="text-4xl font-bold text-gray-800 mt-2">
                      {cartao.valor}
                    </p>
                  </div>
                  <div className={`p-3 rounded-lg ${corMap[cartao.cor]}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Informações Úteis */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Ações Rápidas */}
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Ações Rápidas</h3>
          <div className="space-y-3">
            <a
              href="/empresas"
              className="block w-full text-center btn-primary text-sm"
            >
              Cadastrar Empresa
            </a>
            <a
              href="/licencas"
              className="block w-full text-center btn-primary text-sm"
            >
              Emitir Licença
            </a>
            <a
              href="/mapa"
              className="block w-full text-center btn-secondary text-sm"
            >
              Ver Mapa
            </a>
          </div>
        </div>

        {/* Informações do Sistema */}
        <div className="lg:col-span-2 card">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Informações do Sistema
          </h3>
          <div className="space-y-3 text-sm text-gray-600">
            <p>
              <strong>Versão:</strong> 1.0.0
            </p>
            <p>
              <strong>Última atualização:</strong> {new Date().toLocaleDateString('pt-BR')}
            </p>
            <p>
              <strong>Status:</strong>{' '}
              <span className="text-green-600 font-semibold">Operacional</span>
            </p>
            <p className="text-xs text-gray-500 mt-4">
              Sistema de gestão de licenças para obras em vias públicas - Prefeitura de Niterói
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
