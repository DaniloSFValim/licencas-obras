import React, { useState, useEffect } from 'react';
import { licencasService } from '../services/api';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Corrige ícones do Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png'
});

export const MapaPage = () => {
  const [mapa, setMapa] = useState(null);
  const [licencas, setLicencas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFiltro, setStatusFiltro] = useState('');

  // Inicializa mapa
  useEffect(() => {
    if (mapa) return;

    const novoMapa = L.map('mapa').setView(
      [parseFloat(import.meta.env.VITE_MAP_CENTER_LAT || -22.8835),
       parseFloat(import.meta.env.VITE_MAP_CENTER_LNG || -43.1072)],
      parseInt(import.meta.env.VITE_MAP_ZOOM || 12)
    );

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 19
    }).addTo(novoMapa);

    setMapa(novoMapa);
  }, [mapa]);

  // Carrega licenças
  useEffect(() => {
    carregarLicencas();
  }, [statusFiltro]);

  // Atualiza marcadores quando licenças mudam
  useEffect(() => {
    if (mapa) {
      adicionarMarcadores();
    }
  }, [licencas, mapa]);

  const carregarLicencas = async () => {
    try {
      setLoading(true);
      const response = await licencasService.obterGeoJSON({ status: statusFiltro || undefined });
      setLicencas(response.data.dados.features || []);
    } catch (error) {
      console.error('Erro ao carregar licenças:', error);
    } finally {
      setLoading(false);
    }
  };

  const obterCorStatus = (status) => {
    const cores = {
      ativa: '#10b981',
      expirada: '#9ca3af',
      concluida: '#3b82f6',
      cancelada: '#ef4444'
    };
    return cores[status] || '#6b7280';
  };

  const adicionarMarcadores = () => {
    // Remove marcadores antigos
    mapa.eachLayer((layer) => {
      if (layer instanceof L.Marker) {
        mapa.removeLayer(layer);
      }
    });

    // Adiciona novos marcadores
    licencas.forEach((feature) => {
      const { coordinates } = feature.geometry;
      const { id, numero, tipo_obra, local_obra, status } = feature.properties;

      const cor = obterCorStatus(status);
      
      const icone = L.divIcon({
        html: `
          <div style="
            background-color: ${cor};
            border: 3px solid white;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
          ">
            <span style="color: white; font-weight: bold; font-size: 12px;">📍</span>
          </div>
        `,
        className: 'custom-icon',
        iconSize: [30, 30],
        iconAnchor: [15, 15]
      });

      const marcador = L.marker([coordinates[1], coordinates[0]], { icon: icone })
        .bindPopup(`
          <div style="width: 250px;">
            <h4 style="margin: 0 0 8px 0; font-weight: bold;">${numero}</h4>
            <p style="margin: 4px 0; font-size: 12px;">
              <strong>Tipo:</strong> ${tipo_obra}
            </p>
            <p style="margin: 4px 0; font-size: 12px;">
              <strong>Local:</strong> ${local_obra}
            </p>
            <p style="margin: 4px 0; font-size: 12px;">
              <strong>Status:</strong> <span style="
                padding: 2px 6px;
                border-radius: 4px;
                background-color: ${cor};
                color: white;
              ">${status}</span>
            </p>
          </div>
        `)
        .addTo(mapa);
    });
  };

  return (
    <div className="space-y-6 h-[calc(100vh-150px)]">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Mapa de Licenças</h1>
        <p className="text-gray-600 mt-1">Visualização geográfica das obras autorizadas</p>
      </div>

      {/* Filtros */}
      <div className="card">
        <div className="flex items-center gap-4">
          <label className="font-medium text-gray-700">Filtrar por status:</label>
          <select
            className="input-field"
            value={statusFiltro}
            onChange={(e) => setStatusFiltro(e.target.value)}
          >
            <option value="">Todas as licenças</option>
            <option value="ativa">Ativas</option>
            <option value="expirada">Expiradas</option>
            <option value="concluida">Concluídas</option>
            <option value="cancelada">Canceladas</option>
          </select>
          <span className="text-sm text-gray-600">
            {loading ? 'Carregando...' : `${licencas.length} licença(s)`}
          </span>
        </div>
      </div>

      {/* Legenda */}
      <div className="card p-4">
        <p className="font-semibold text-gray-800 mb-3">Legenda:</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center gap-2">
            <div style={{
              width: '12px',
              height: '12px',
              borderRadius: '50%',
              backgroundColor: '#10b981'
            }}></div>
            <span className="text-sm">Ativa</span>
          </div>
          <div className="flex items-center gap-2">
            <div style={{
              width: '12px',
              height: '12px',
              borderRadius: '50%',
              backgroundColor: '#3b82f6'
            }}></div>
            <span className="text-sm">Concluída</span>
          </div>
          <div className="flex items-center gap-2">
            <div style={{
              width: '12px',
              height: '12px',
              borderRadius: '50%',
              backgroundColor: '#9ca3af'
            }}></div>
            <span className="text-sm">Expirada</span>
          </div>
          <div className="flex items-center gap-2">
            <div style={{
              width: '12px',
              height: '12px',
              borderRadius: '50%',
              backgroundColor: '#ef4444'
            }}></div>
            <span className="text-sm">Cancelada</span>
          </div>
        </div>
      </div>

      {/* Mapa */}
      <div 
        id="mapa" 
        className="card flex-1 p-0 rounded-lg overflow-hidden"
        style={{ height: '500px' }}
      />
    </div>
  );
};
