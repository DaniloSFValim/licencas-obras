import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Lock, Mail } from 'lucide-react';

export const LoginPage = () => {
  const navigate = useNavigate();
  const { login, loading, erro } = useAuth();
  const [email, setEmail] = useState('admin@niteroi.rj.gov.br');
  const [senha, setSenha] = useState('');
  const [erroLocal, setErroLocal] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErroLocal('');

    if (!email || !senha) {
      setErroLocal('Email e senha são obrigatórios');
      return;
    }

    const sucesso = await login(email, senha);
    if (sucesso) {
      navigate('/dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Niterói</h1>
          <p className="text-gray-600 text-sm">Sistema de Licenças para Obras</p>
        </div>

        {/* Erros */}
        {(erroLocal || erro) && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-700 text-sm">{erroLocal || erro}</p>
          </div>
        )}

        {/* Formulário */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Email */}
          <div>
            <label className="label">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 text-gray-400 h-5 w-5" />
              <input
                type="email"
                className="input-field pl-10"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={loading}
              />
            </div>
          </div>

          {/* Senha */}
          <div>
            <label className="label">Senha</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 text-gray-400 h-5 w-5" />
              <input
                type="password"
                className="input-field pl-10"
                placeholder="••••••••"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                disabled={loading}
              />
            </div>
          </div>

          {/* Botão */}
          <button
            type="submit"
            disabled={loading}
            className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Entrando...' : 'Entrar'}
          </button>
        </form>

        {/* Informações */}
        <div className="mt-8 pt-6 border-t border-gray-200">
          <p className="text-gray-600 text-xs text-center">
            <strong>Demo:</strong> Use o email padrão e qualquer senha para teste
          </p>
        </div>
      </div>
    </div>
  );
};
