import React, { useState, useEffect } from 'react';
import { empresasService } from '../services/api';
import { Plus, Edit2, Trash2, Search } from 'lucide-react';

export const EmpresasPage = () => {
  const [empresas, setEmpresas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState('');
  const [busca, setBusca] = useState('');
  const [modalAberto, setModalAberto] = useState(false);
  const [formulario, setFormulario] = useState({
    nome: '',
    cnpj: '',
    email: '',
    telefone: '',
    endereco: '',
    bairro: '',
    representante: '',
    telefone_representante: '',
    email_representante: ''
  });
  const [editandoId, setEditandoId] = useState(null);

  // Carrega empresas
  useEffect(() => {
    carregarEmpresas();
  }, []);

  const carregarEmpresas = async () => {
    try {
      setLoading(true);
      setErro('');
      const response = await empresasService.listar({ nome: busca });
      setEmpresas(response.data.dados.empresas || []);
    } catch (error) {
      setErro('Erro ao carregar empresas');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleBusca = (valor) => {
    setBusca(valor);
  };

  const abrirModal = (empresa = null) => {
    if (empresa) {
      setFormulario(empresa);
      setEditandoId(empresa.id);
    } else {
      setFormulario({
        nome: '',
        cnpj: '',
        email: '',
        telefone: '',
        endereco: '',
        bairro: '',
        representante: '',
        telefone_representante: '',
        email_representante: ''
      });
      setEditandoId(null);
    }
    setModalAberto(true);
  };

  const fecharModal = () => {
    setModalAberto(false);
    setEditandoId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editandoId) {
        await empresasService.atualizar(editandoId, formulario);
      } else {
        await empresasService.criar(formulario);
      }
      fecharModal();
      carregarEmpresas();
    } catch (error) {
      setErro(error.response?.data?.mensagem || 'Erro ao salvar empresa');
    }
  };

  const handleDeletar = async (id) => {
    if (!window.confirm('Tem certeza que deseja deletar essa empresa?')) return;

    try {
      await empresasService.deletar(id);
      carregarEmpresas();
    } catch (error) {
      setErro('Erro ao deletar empresa');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormulario(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Empresas</h1>
          <p className="text-gray-600 mt-1">Gestão de empresas autorizadas</p>
        </div>
        <button
          onClick={() => abrirModal()}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="h-5 w-5" />
          Nova Empresa
        </button>
      </div>

      {/* Erros */}
      {erro && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-700 text-sm">{erro}</p>
        </div>
      )}

      {/* Busca */}
      <div className="card">
        <div className="relative">
          <Search className="absolute left-3 top-3 text-gray-400 h-5 w-5" />
          <input
            type="text"
            placeholder="Buscar por nome ou CNPJ..."
            className="input-field pl-10"
            value={busca}
            onChange={(e) => {
              handleBusca(e.target.value);
            }}
          />
        </div>
      </div>

      {/* Tabela */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Nome</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">CNPJ</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Email</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Telefone</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-700">Ações</th>
              </tr>
            </thead>
            <tbody>
              {empresas.length === 0 ? (
                <tr>
                  <td colSpan="5" className="text-center py-8 text-gray-600">
                    Nenhuma empresa encontrada
                  </td>
                </tr>
              ) : (
                empresas.map(empresa => (
                  <tr key={empresa.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-4">{empresa.nome}</td>
                    <td className="py-3 px-4 font-mono text-sm">{empresa.cnpj}</td>
                    <td className="py-3 px-4 text-sm">{empresa.email || '-'}</td>
                    <td className="py-3 px-4 text-sm">{empresa.telefone || '-'}</td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => abrirModal(empresa)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded"
                          title="Editar"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeletar(empresa.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded"
                          title="Deletar"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      {modalAberto && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            {/* Header Modal */}
            <div className="p-6 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white">
              <h2 className="text-xl font-semibold text-gray-800">
                {editandoId ? 'Editar Empresa' : 'Nova Empresa'}
              </h2>
              <button
                onClick={fecharModal}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>

            {/* Formulário */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Nome *</label>
                  <input
                    type="text"
                    name="nome"
                    className="input-field"
                    value={formulario.nome}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div>
                  <label className="label">CNPJ *</label>
                  <input
                    type="text"
                    name="cnpj"
                    className="input-field"
                    value={formulario.cnpj}
                    onChange={handleInputChange}
                    required
                    disabled={!!editandoId}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Email</label>
                  <input
                    type="email"
                    name="email"
                    className="input-field"
                    value={formulario.email}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <label className="label">Telefone</label>
                  <input
                    type="tel"
                    name="telefone"
                    className="input-field"
                    value={formulario.telefone}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div>
                <label className="label">Endereço *</label>
                <input
                  type="text"
                  name="endereco"
                  className="input-field"
                  value={formulario.endereco}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div>
                <label className="label">Bairro</label>
                <input
                  type="text"
                  name="bairro"
                  className="input-field"
                  value={formulario.bairro}
                  onChange={handleInputChange}
                />
              </div>

              <div className="pt-4 border-t border-gray-200">
                <h3 className="font-semibold text-gray-800 mb-4">Representante</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="label">Nome</label>
                    <input
                      type="text"
                      name="representante"
                      className="input-field"
                      value={formulario.representante}
                      onChange={handleInputChange}
                    />
                  </div>
                  <div>
                    <label className="label">Telefone</label>
                    <input
                      type="tel"
                      name="telefone_representante"
                      className="input-field"
                      value={formulario.telefone_representante}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                <div className="mt-4">
                  <label className="label">Email</label>
                  <input
                    type="email"
                    name="email_representante"
                    className="input-field"
                    value={formulario.email_representante}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              {/* Botões */}
              <div className="flex gap-4 pt-6 border-t border-gray-200">
                <button
                  type="submit"
                  className="flex-1 btn-primary"
                >
                  {editandoId ? 'Atualizar' : 'Criar'} Empresa
                </button>
                <button
                  type="button"
                  onClick={fecharModal}
                  className="flex-1 btn-secondary"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
