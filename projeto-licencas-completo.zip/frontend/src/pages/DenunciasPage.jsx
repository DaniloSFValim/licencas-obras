import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Plus, Edit2, Trash2, Search, MapPin } from 'lucide-react';

const denunciasService = {
  listar: (filtros = {}) =>
    axios.get('/api/denuncias', { 
      params: filtros,
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    }),
  
  criar: (dados) =>
    axios.post('/api/denuncias', dados, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    }),
  
  atualizar: (id, dados) =>
    axios.put(`/api/denuncias/${id}`, dados, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    }),
  
  deletar: (id) =>
    axios.delete(`/api/denuncias/${id}`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    })
};

export const DenunciasPage = () => {
  const [denuncias, setDenuncias] = useState([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState('');
  const [statusFiltro, setStatusFiltro] = useState('');
  const [modalAberto, setModalAberto] = useState(false);
  const [formulario, setFormulario] = useState({
    titulo: '',
    descricao: '',
    canal: 'manual',
    endereco: '',
    latitude: '',
    longitude: '',
    foto_url: '',
    status: 'aberta',
    observacoes_investigacao: ''
  });
  const [editandoId, setEditandoId] = useState(null);

  // Carrega denúncias
  useEffect(() => {
    carregarDenuncias();
  }, [statusFiltro]);

  const carregarDenuncias = async () => {
    try {
      setLoading(true);
      setErro('');
      const response = await denunciasService.listar({ 
        status: statusFiltro || undefined 
      });
      setDenuncias(response.data.dados.denuncias || []);
    } catch (error) {
      setErro('Erro ao carregar denúncias');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const abrirModal = (denuncia = null) => {
    if (denuncia) {
      setFormulario(denuncia);
      setEditandoId(denuncia.id);
    } else {
      setFormulario({
        titulo: '',
        descricao: '',
        canal: 'manual',
        endereco: '',
        latitude: '',
        longitude: '',
        foto_url: '',
        status: 'aberta',
        observacoes_investigacao: ''
      });
      setEditandoId(null);
    }
    setModalAberto(true);
  };

  const fecharModal = () => {
    setModalAberto(false);
    setEditandoId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editandoId) {
        await denunciasService.atualizar(editandoId, formulario);
      } else {
        await denunciasService.criar(formulario);
      }
      fecharModal();
      carregarDenuncias();
    } catch (error) {
      setErro(error.response?.data?.mensagem || 'Erro ao salvar denúncia');
    }
  };

  const handleDeletar = async (id) => {
    if (!window.confirm('Tem certeza que deseja deletar essa denúncia?')) return;

    try {
      await denunciasService.deletar(id);
      carregarDenuncias();
    } catch (error) {
      setErro('Erro ao deletar denúncia');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormulario(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const obterCorStatus = (status) => {
    const cores = {
      aberta: 'bg-red-100 text-red-800',
      investigada: 'bg-yellow-100 text-yellow-800',
      resolvida: 'bg-green-100 text-green-800',
      descartada: 'bg-gray-100 text-gray-800'
    };
    return cores[status] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Denúncias</h1>
          <p className="text-gray-600 mt-1">Gestão de denúncias sobre obras</p>
        </div>
        <button
          onClick={() => abrirModal()}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="h-5 w-5" />
          Nova Denúncia
        </button>
      </div>

      {/* Erros */}
      {erro && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-700 text-sm">{erro}</p>
        </div>
      )}

      {/* Filtros */}
      <div className="card">
        <div className="flex items-center gap-4">
          <label className="font-medium text-gray-700">Status:</label>
          <select
            className="input-field"
            value={statusFiltro}
            onChange={(e) => setStatusFiltro(e.target.value)}
          >
            <option value="">Todas</option>
            <option value="aberta">Aberta</option>
            <option value="investigada">Investigada</option>
            <option value="resolvida">Resolvida</option>
            <option value="descartada">Descartada</option>
          </select>
        </div>
      </div>

      {/* Tabela */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Título</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Descrição</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Canal</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-700">Ações</th>
              </tr>
            </thead>
            <tbody>
              {denuncias.length === 0 ? (
                <tr>
                  <td colSpan="5" className="text-center py-8 text-gray-600">
                    Nenhuma denúncia encontrada
                  </td>
                </tr>
              ) : (
                denuncias.map(denuncia => (
                  <tr key={denuncia.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium">{denuncia.titulo || 'Sem título'}</td>
                    <td className="py-3 px-4 truncate text-gray-600">{denuncia.descricao}</td>
                    <td className="py-3 px-4 capitalize">{denuncia.canal}</td>
                    <td className="py-3 px-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${obterCorStatus(denuncia.status)}`}>
                        {denuncia.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        {denuncia.localizacao && (
                          <a
                            href={`/mapa?denuncia=${denuncia.id}`}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded"
                            title="Ver no mapa"
                          >
                            <MapPin className="h-4 w-4" />
                          </a>
                        )}
                        <button
                          onClick={() => abrirModal(denuncia)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded"
                          title="Editar"
                        >
                          <Edit2 className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeletar(denuncia.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded"
                          title="Deletar"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      {modalAberto && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            {/* Header Modal */}
            <div className="p-6 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white">
              <h2 className="text-xl font-semibold text-gray-800">
                {editandoId ? 'Editar Denúncia' : 'Nova Denúncia'}
              </h2>
              <button
                onClick={fecharModal}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>

            {/* Formulário */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="label">Título</label>
                <input
                  type="text"
                  name="titulo"
                  className="input-field"
                  value={formulario.titulo}
                  onChange={handleInputChange}
                />
              </div>

              <div>
                <label className="label">Descrição *</label>
                <textarea
                  name="descricao"
                  className="input-field"
                  rows="4"
                  value={formulario.descricao}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Canal</label>
                  <select
                    name="canal"
                    className="input-field"
                    value={formulario.canal}
                    onChange={handleInputChange}
                  >
                    <option value="manual">Manual</option>
                    <option value="email">Email</option>
                    <option value="whatsapp">WhatsApp</option>
                    <option value="formulario">Formulário</option>
                  </select>
                </div>
                <div>
                  <label className="label">Status</label>
                  <select
                    name="status"
                    className="input-field"
                    value={formulario.status}
                    onChange={handleInputChange}
                  >
                    <option value="aberta">Aberta</option>
                    <option value="investigada">Investigada</option>
                    <option value="resolvida">Resolvida</option>
                    <option value="descartada">Descartada</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="label">Endereço</label>
                <input
                  type="text"
                  name="endereco"
                  className="input-field"
                  value={formulario.endereco}
                  onChange={handleInputChange}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label">Latitude</label>
                  <input
                    type="number"
                    step="0.000001"
                    name="latitude"
                    className="input-field"
                    value={formulario.latitude}
                    onChange={handleInputChange}
                  />
                </div>
                <div>
                  <label className="label">Longitude</label>
                  <input
                    type="number"
                    step="0.000001"
                    name="longitude"
                    className="input-field"
                    value={formulario.longitude}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div>
                <label className="label">Observações de Investigação</label>
                <textarea
                  name="observacoes_investigacao"
                  className="input-field"
                  rows="3"
                  value={formulario.observacoes_investigacao}
                  onChange={handleInputChange}
                />
              </div>

              {/* Botões */}
              <div className="flex gap-4 pt-6 border-t border-gray-200">
                <button
                  type="submit"
                  className="flex-1 btn-primary"
                >
                  {editandoId ? 'Atualizar' : 'Criar'} Denúncia
                </button>
                <button
                  type="button"
                  onClick={fecharModal}
                  className="flex-1 btn-secondary"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
