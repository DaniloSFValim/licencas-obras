import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  Menu,
  X,
  LogOut,
  Home,
  Building2,
  FileText,
  Map,
  AlertCircle,
  BarChart3,
  Users
} from 'lucide-react';

export const Layout = ({ children }) => {
  const navigate = useNavigate();
  const { usuario, logout, ehAdmin } = useAuth();
  const [menuAberto, setMenuAberto] = useState(false);

  const menuItems = [
    { label: 'Dashboard', href: '/dashboard', icon: Home },
    { label: 'Empresas', href: '/empresas', icon: Building2 },
    { label: 'Licenças', href: '/licencas', icon: FileText },
    { label: 'Mapa', href: '/mapa', icon: Map },
    { label: 'Denúncias', href: '/denuncias', icon: AlertCircle },
    { label: 'Análise Pós-Obra', href: '/analise', icon: BarChart3 },
    ...(ehAdmin ? [{ label: 'Usuários', href: '/usuarios', icon: Users }] : [])
  ];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside
        className={`${
          menuAberto ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 fixed lg:relative z-40 w-64 h-full bg-gray-900 text-white shadow-lg transition-transform duration-300`}
      >
        {/* Logo */}
        <div className="p-6 border-b border-gray-700">
          <h1 className="text-2xl font-bold">Niterói</h1>
          <p className="text-gray-400 text-xs mt-1">Sistema de Licenças</p>
        </div>

        {/* Menu */}
        <nav className="p-6 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.href}
                onClick={() => {
                  navigate(item.href);
                  setMenuAberto(false);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-800 transition-colors text-left"
              >
                <Icon className="h-5 w-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Usuário */}
        <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-gray-700 bg-gray-800">
          <div className="mb-4">
            <p className="text-sm text-gray-400">Conectado como</p>
            <p className="font-semibold text-white truncate">{usuario?.nome}</p>
            <p className="text-xs text-gray-400 capitalize">{usuario?.role}</p>
          </div>
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg text-white transition-colors text-sm"
          >
            <LogOut className="h-4 w-4" />
            <span>Sair</span>
          </button>
        </div>
      </aside>

      {/* Overlay mobile */}
      {menuAberto && (
        <div
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-30"
          onClick={() => setMenuAberto(false)}
        />
      )}

      {/* Conteúdo Principal */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between shadow-sm">
          <button
            onClick={() => setMenuAberto(!menuAberto)}
            className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
          >
            {menuAberto ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>

          <h2 className="text-xl font-semibold text-gray-800 flex-1 lg:flex-none">
            Sistema de Licenças
          </h2>

          <div className="text-right">
            <p className="text-sm text-gray-600">{usuario?.nome}</p>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
};
