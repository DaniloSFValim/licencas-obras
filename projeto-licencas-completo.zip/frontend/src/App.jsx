import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { RotaProtegida, RotaAdmin } from './components/RotaProtegida';
import { Layout } from './components/Layout';

// Páginas
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { EmpresasPage } from './pages/EmpresasPage';
import { LicencasPage } from './pages/LicencasPage';
import { MapaPage } from './pages/MapaPage';
import { DenunciasPage, AnalisePostObraPage, UsuariosPage } from './pages/index';

function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          {/* Rota pública */}
          <Route path="/login" element={<LoginPage />} />

          {/* Rotas protegidas */}
          <Route
            path="/dashboard"
            element={
              <RotaProtegida>
                <Layout>
                  <DashboardPage />
                </Layout>
              </RotaProtegida>
            }
          />

          <Route
            path="/empresas"
            element={
              <RotaProtegida>
                <Layout>
                  <EmpresasPage />
                </Layout>
              </RotaProtegida>
            }
          />

          <Route
            path="/licencas"
            element={
              <RotaProtegida>
                <Layout>
                  <LicencasPage />
                </Layout>
              </RotaProtegida>
            }
          />

          <Route
            path="/mapa"
            element={
              <RotaProtegida>
                <Layout>
                  <MapaPage />
                </Layout>
              </RotaProtegida>
            }
          />

          <Route
            path="/denuncias"
            element={
              <RotaProtegida>
                <Layout>
                  <DenunciasPage />
                </Layout>
              </RotaProtegida>
            }
          />

          <Route
            path="/analise"
            element={
              <RotaProtegida>
                <Layout>
                  <AnalisePostObraPage />
                </Layout>
              </RotaProtegida>
            }
          />

          {/* Rota admin */}
          <Route
            path="/usuarios"
            element={
              <RotaAdmin>
                <Layout>
                  <UsuariosPage />
                </Layout>
              </RotaAdmin>
            }
          />

          {/* Redirect padrão */}
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App;
