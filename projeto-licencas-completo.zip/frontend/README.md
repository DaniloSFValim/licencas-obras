# Frontend - Sistema de Licenças

Interface web React + Vite para o sistema de gestão de licenças para obras em vias públicas.

## Requisitos

- Node.js 18+
- npm ou yarn

## Instalação

### 1. Instalar dependências

```bash
npm install
```

### 2. Configurar variáveis de ambiente

```bash
cp .env.example .env.local
```

Edite o arquivo `.env.local`:

```
VITE_API_BASE_URL=http://localhost:5000/api
VITE_MAP_CENTER_LAT=-22.8835
VITE_MAP_CENTER_LNG=-43.1072
VITE_MAP_ZOOM=12
```

### 3. Iniciar servidor de desenvolvimento

```bash
npm run dev
```

O frontend estará rodando em `http://localhost:5173`

## Scripts

```bash
# Desenvolvimento
npm run dev

# Build para produção
npm run build

# Preview do build
npm run preview

# Lint (se configurado)
npm run lint
```

## Estrutura de Pastas

```
src/
├── components/        # Componentes reutilizáveis
│   ├── Layout.jsx    # Layout principal
│   └── RotaProtegida.jsx
├── context/          # React Context
│   └── AuthContext.jsx
├── pages/            # Páginas/telas
│   ├── LoginPage.jsx
│   ├── DashboardPage.jsx
│   ├── EmpresasPage.jsx
│   ├── LicencasPage.jsx
│   ├── MapaPage.jsx
│   └── index.js
├── services/         # Integração com API
│   └── api.js
├── App.jsx           # Componente raiz
├── main.jsx          # Entry point
└── index.css         # Estilos globais
```

## Features Implementadas

### ✅ Autenticação
- Login com JWT
- Contexto de autenticação
- Rotas protegidas
- Controle de roles (admin/operador)

### ✅ Dashboard
- Estatísticas
- Atalhos rápidos
- Informações do sistema

### ✅ Empresas
- Listar empresas
- Criar nova empresa
- Editar empresa
- Deletar empresa (soft delete)
- Busca por nome/CNPJ

### ✅ Licenças
- Listar licenças
- Emitir nova licença
- Editar licença
- Cancelar licença (soft delete)
- Filtrar por status
- Gerar PDF automático
- Coordenadas geográficas

### ✅ Mapa Interativo
- Visualização de licenças por localização
- Marcadores coloridos por status
- Popup com informações
- Filtro por status
- Legenda

### 🔄 Em Desenvolvimento
- Gestão de denúncias
- Análise pós-obra
- Gestão de usuários (admin)

## Tecnologias Utilizadas

- **React 18** - UI library
- **React Router** - Roteamento
- **Vite** - Build tool
- **Axios** - HTTP client
- **Tailwind CSS** - Styling
- **Leaflet** - Mapas
- **Lucide Icons** - Ícones
- **Date-fns** - Manipulação de datas

## Variáveis de Ambiente

| Variável | Descrição | Padrão |
|----------|-----------|--------|
| `VITE_API_BASE_URL` | URL da API backend | `http://localhost:5000/api` |
| `VITE_MAP_CENTER_LAT` | Latitude do centro do mapa | `-22.8835` |
| `VITE_MAP_CENTER_LNG` | Longitude do centro do mapa | `-43.1072` |
| `VITE_MAP_ZOOM` | Zoom inicial do mapa | `12` |

## Resposta de API

A API retorna respostas no formato:

```json
{
  "sucesso": true/false,
  "mensagem": "Mensagem de sucesso ou erro",
  "dados": {}
}
```

## Autenticação

Usa JWT (JSON Web Tokens):
- Token é armazenado em `localStorage`
- Enviado no header: `Authorization: Bearer {token}`
- Token expira em 7 dias
- Auto-refresh disponível

## Componentes Principais

### AuthProvider
Gerencia estado de autenticação globalmente

### RotaProtegida
Protege rotas que requerem autenticação

### RotaAdmin
Protege rotas que requerem role de admin

### Layout
Layout principal com sidebar e header

## Guia de Uso

1. **Login**: Acesse `/login` com credenciais
2. **Dashboard**: Visualize estatísticas
3. **Empresas**: Cadastre e gerencie empresas
4. **Licenças**: Emita licenças para obras
5. **Mapa**: Visualize obras geolokalizadas
6. **Denúncias**: (Em desenvolvimento)

## Debugging

Para debugging, abra o DevTools do navegador (F12):
- Console: Veja logs e erros
- Network: Monitore requisições HTTP
- Storage: Veja token localStorage

## Próximas Melhorias

- Temas (dark mode)
- Responsividade mobile melhorada
- Validações customizadas
- Paginação na tabela
- Export de relatórios
- Notificações em tempo real
